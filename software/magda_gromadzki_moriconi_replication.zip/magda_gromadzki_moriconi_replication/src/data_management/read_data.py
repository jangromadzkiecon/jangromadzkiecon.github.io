import pandas as pd
from bld.project_paths import project_paths_join as ppj

def import_dta(country,year):
    ''' Import a cleaned dta file
    '''
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Norway': 'no', 'Poland': 'pl', 
    'Portugal': 'pt','Romania': 'ro', 'Sweden': 'se', 'Slovakia': 'sk', 'United Kingdom': 'uk'}
    path = ppj("OUT_DATA", 'ses_' + country_codes[country] + '_' + str(year) + '_cleaned.dta')
    df = pd.read_stata(path, convert_categoricals=False)
    return df