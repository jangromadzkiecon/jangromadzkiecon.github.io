"""
Descriptive statistics for SES data
"""


import sys
import json
import logging
import pickle
import numpy as np
import pandas as pd
from src.data_management.read_data import import_dta 
from src.model_code.ineq_indices import variance_weighted, atkinson, gini, theil_t, dispersion_quantiles, share_quantiles  
from bld.project_paths import project_paths_join as ppj
from itertools import groupby
import matplotlib.pyplot as plt

def label_len(my_index,level):
    labels = my_index.get_level_values(level)
    return [(k, sum(1 for i in g)) for k,g in groupby(labels)]

def label_group_bar_table(df,out_path,double_label=True,figsize=(20,3)):
    plt.rcParams["figure.figsize"] = figsize
    if figsize[1]==10:
        fontsize_factor = figsize[1]/4
    else:
        fontsize_factor=1.1
    tableau20 =[(221, 117, 142),(186, 23, 54)]
    for i in range(len(tableau20)):
        r, g, b = tableau20[i]
        tableau20[i] = (r / 255., g / 255., b / 255.)    
    ax = df.plot(kind='bar',stacked=False,color=tableau20)
    if double_label==True:    
        ax.set_xticklabels('')
        ax.set_xlabel('')    
        ypos = -.1
        scale = 1./df.index.size
        for level in range(df.index.nlevels)[::-1]:
            pos = 0
            for label, rpos in label_len(df.index,level):
                lxpos = (pos + .5 * rpos)*scale
                ax.text(lxpos, ypos, label,fontsize=fontsize_factor*10, ha='center', transform=ax.transAxes)
                pos += rpos
            ypos -= .1
    else:
        plt.xticks(rotation=0,fontsize=fontsize_factor*10)
    plt.yticks(fontsize=fontsize_factor*10)
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(True)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(True)

    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")
    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()  
    if figsize[1]==10:
        plt.legend(frameon=False, loc='lower center',fontsize=fontsize_factor*10, bbox_to_anchor=(0.5, -0.25), ncol=3, handlelength=4)        
    else:
        plt.legend(frameon=False, loc='lower center',fontsize=fontsize_factor*10, bbox_to_anchor=(0.5, -0.5), ncol=3, handlelength=4)

    plt.savefig(out_path, bbox_inches="tight",  dpi=400)
    plt.savefig(out_path[:-4] + '.pdf', bbox_inches="tight")        

def df_decile_dispersion(years,countries,dec_dict_key,dec_oecd_val,df_oecd_,dict_ineq):
    ind_fin = pd.MultiIndex.from_product([countries, years], names=['country', 'year'])
    df_fin = pd.DataFrame(index=ind_fin,columns=['SES', 'OECD'])
    df_oecd_ = df_oecd_.set_index(['Country','Time','SERIES'])
    for c in countries:
        for y in years:
            df_fin.loc[(c,y),'SES'] = dict_ineq[str(y)][c][dec_dict_key]
            df_fin.loc[(c,y),'OECD'] = df_oecd_.loc[(c,y,dec_oecd_val),'Value']

    return df_fin


def validation_deciles(years, json_path, countries, suffix):
    fig_name_90_10 = ppj('OUT_FIGURES','deciles_validation_oecd_90_10' + suffix + '.png')
    fig_name_50_10 = ppj('OUT_FIGURES','deciles_validation_oecd_50_10' + suffix + '.png')
    fig_name_90_50 = ppj('OUT_FIGURES','deciles_validation_oecd_90_50' + suffix + '.png')
    df_oecd = pd.read_csv(ppj('IN_DATA', 'DEC_I_08052020185125503.csv'))

    dict_cntry_map = {'Czech Republic': 'Czechia', 'Slovak Republic': 'Slovakia'}
    df_oecd['Country'] = df_oecd['Country'].replace(dict_cntry_map)
    with open(ppj('OUT_DATA',json_path)) as json_file:
        dict_measures_ = json.load(json_file)
    df_90_10 = df_decile_dispersion(years=years,countries=countries,
        dec_dict_key='90_10_dispersion',dec_oecd_val='P91',
        df_oecd_=df_oecd, dict_ineq=dict_measures_)
    df_90_50 = df_decile_dispersion(years=years,countries=countries,
        dec_dict_key='90_50_dispersion',dec_oecd_val='P95',
        df_oecd_=df_oecd, dict_ineq=dict_measures_)
    df_50_10 = df_decile_dispersion(years=years,countries=countries,
        dec_dict_key='50_10_dispersion',dec_oecd_val='P51',
        df_oecd_=df_oecd, dict_ineq=dict_measures_) 
    label_group_bar_table(df_90_10,fig_name_90_10,figsize=(20,2))  
    label_group_bar_table(df_90_50,fig_name_90_50,figsize=(20,2))  
    label_group_bar_table(df_50_10,fig_name_50_10,figsize=(20,2))           

def df_mean(countries,df_oecd_,dict_ineq):
    df_fin = pd.DataFrame(index=countries,columns=['SES', 'OECD'])
    df_oecd_ = df_oecd_.set_index(['Country','Time'])
    dict_ex_rate = {
    'Estonia': 15.6466,
    'Latvia': 0.702804,
    'Slovakia': 30.1260
    }
    for c in countries:
        mean_dict_key = 'mean_earn_ann'    
        if c in ['Estonia', 'Latvia', 'Slovakia']: 
            df_fin.loc[c,'SES'] =100* dict_ineq[str(2014)][c][mean_dict_key]/(dict_ineq[str(2006)][c][mean_dict_key]/dict_ex_rate[c])
        else:
            df_fin.loc[c,'SES'] =100* dict_ineq[str(2014)][c][mean_dict_key]/dict_ineq[str(2006)][c][mean_dict_key]
        df_fin.loc[c,'OECD'] =100* df_oecd_.loc[(c,2014),'Value']/df_oecd_.loc[(c,2006),'Value']
    return df_fin

def validation_means(json_path, countries, suffix):
    fig_name = ppj('OUT_FIGURES','means_validation_oecd' + suffix + '.png')
    df_oecd = pd.read_csv(ppj('IN_DATA', 'AV_AN_WAGE_08052020184431782.csv'))
    dict_cntry_map = {'Czech Republic': 'Czechia', 'Slovak Republic': 'Slovakia'}
    df_oecd['Country'] = df_oecd['Country'].replace(dict_cntry_map)
    with open(ppj('OUT_DATA',json_path)) as json_file:
        dict_measures_ = json.load(json_file)
    df_means = df_mean(countries=countries,
        df_oecd_=df_oecd, dict_ineq=dict_measures_)
    label_group_bar_table(df_means,fig_name,double_label=False,figsize=(20,10))

def validation_nace(country, suffix):
    '''
    '''
    fig_name = ppj('OUT_FIGURES','sectors_validation_oecd' + suffix + '.png')
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}    
    dict_isic_nace = {'B':['05_09'], 'C':['10_33'], 'D_E':['35','36_39'], 
    'F':['41_43'], 'G': ['45_47'], 'H_J': ['49_53','58_63'], 'I': ['55_56'],
    'L_M_N': ['68','69_75', '77_82']}
    fig_name = ppj('OUT_FIGURES','sectors_validation_oecd_' + country_codes[country] + suffix + '.png')
    sectors_list = list(dict_isic_nace.keys())
    years = [2006,2014]
    ind_fin = pd.MultiIndex.from_product([years, sectors_list], names=['year', 'sector'])
    df_fin = pd.DataFrame(index=ind_fin,columns=['SES', 'OECD'])
    df_oecd = pd.read_csv(ppj('IN_DATA', 'SSIS_BSC_ISIC4_10052020114058571.csv'))
    df_oecd['nace'] = np.nan 
    for s in dict_isic_nace.keys():
        df_oecd.loc[df_oecd['ISIC4'].isin(dict_isic_nace[s]), 'nace'] = s
    dict_cntry_map = {'Czech Republic': 'Czechia', 'Slovak Republic': 'Slovakia'}
    df_oecd['Country'] = df_oecd['Country'].replace(dict_cntry_map)    
    df_oecd = df_oecd.fillna(0)
    df_oecd = df_oecd.groupby(['Country','Time','nace']).sum()
    for y in years:
        df_in = import_dta(country=country, year=y)
        df_in = df_in[df_in['m_nace2_uni'].isin(sectors_list)]
        df_in = df_in.groupby(['m_nace2_uni']).sum()
        for s in sectors_list:
            df_fin.loc[(y,s),'OECD'] = df_oecd.loc[(country,y,s),'Value']
            df_fin.loc[(y,s),'SES'] = df_in.loc[s,'m_weight_employees']
    for c in ['SES', 'OECD']:
        df_fin[c] = df_fin[c]/df_fin[c].sum()
    df_fin = df_fin.reset_index()
    df_fin['sector'] = df_fin['sector'].str.replace('_', '+')
    df_fin = df_fin.set_index(['year', 'sector'])
    label_group_bar_table(df_fin,fig_name,figsize=(20,2))


cntries = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Netherlands', 'Norway', 'Poland', 'Portugal', 'Romania', 'Sweden', 'Slovakia']    
cntries_cee = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Poland', 'Romania', 'Slovakia']
cntries_west = ['Netherlands', 'Norway', 'Portugal', 'Sweden']
years_ = [2006,2010,2014]

cntries_cee_norobg = ['Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Poland', 'Slovakia']
country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
'Sweden': 'se', 'Slovakia': 'sk'}
for c in cntries_cee:
    validation_nace(country=c, suffix='')
validation_deciles(years=years_, json_path='ineq_dict_full.json', countries=cntries_cee, suffix='')
validation_means(json_path='ineq_dict_full.json', countries=cntries_cee_norobg, suffix='')