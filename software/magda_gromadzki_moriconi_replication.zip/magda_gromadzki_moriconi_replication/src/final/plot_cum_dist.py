import json
import pickle
import sys
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from src.final.plot_code import line_plot_connect
from bld.project_paths import project_paths_join as ppj
from src.data_management.read_data import import_dta 

def plot_cum_dist(years, country,suff):  
    fig_name =  'cum_dist_' + country + suff + '.png' 
    df_fin = pd.DataFrame(columns=[str(x) for x in years],index=list(range(1,100)))
    for i in years:
        df_stata = import_dta(country=country, year=i)
        df_stata = df_stata[df_stata['sample_999']==1]
        df_stata = df_stata.sort_values(by=['m_earnings_euro'], ascending=True)
        df_stata['cum_weight'] = df_stata['m_weight_employees'].cumsum()/df_stata['m_weight_employees'].sum()  
        df_stata['cum_weight'] = df_stata['cum_weight']*100
        for p in df_fin.index:
            df_fin.loc[p,str(i)] = float(df_stata[df_stata['cum_weight']>=p]['m_earnings_euro'].iloc[0])
    line_plot_connect(df=df_fin, columns=[str(x) for x in years], 
        out_path=(ppj('OUT_FIGURES',fig_name)), xtitle='Percentile of hourly wages',
        ytitle='Hourly wages (euro)',log_scale=True)

def plot_cum_dist_firms(years, country,suff):  
    wm = lambda x: np.average(x, weights=df_stata.loc[x.index, "m_weight_employees"])    
    func = {'m_weight_employees': 'sum', 'm_earnings_euro': wm }
       
    fig_name =  'cum_dist_' + country + suff + '_firms.png' 
    df_fin = pd.DataFrame(columns=[str(x) for x in years],index=list(range(1,100)))
    for i in years:
        df_stata = import_dta(country=country, year=i)
        df_stata = df_stata[df_stata['sample_999']==1]
        df_stata = df_stata.groupby(["m_firm_id"]).agg(func)
        df_stata = df_stata.sort_values(by=['m_earnings_euro'], ascending=True)
        df_stata['cum_weight'] = df_stata['m_weight_employees'].cumsum()/df_stata['m_weight_employees'].sum()  
        df_stata['cum_weight'] = df_stata['cum_weight']*100
        for p in df_fin.index:
            df_fin.loc[p,str(i)] = float(df_stata[df_stata['cum_weight']>=p]['m_earnings_euro'].iloc[0])
    line_plot_connect(df=df_fin, columns=[str(x) for x in years], 
        out_path=(ppj('OUT_FIGURES',fig_name)), xtitle='Percentile of hourly wages',
        ytitle='Hourly wages (euro)',log_scale=True)

def plot_cum_dist_firms_ind(years, country,suff):  
    wm = lambda x: np.average(x, weights=df_stata.loc[x.index, "m_weight_employees"])    
    func = {'m_weight_employees': 'sum', 'ln_m_earnings_euro': wm }
       
    fig_name =  'cum_dist_' + country + suff + '_firms_ind_log_change.png' 
    fig_name_ind =  'cum_dist_' + country + suff + '_individual_log_change.png' 
    df_fin = pd.DataFrame(columns=[str(x) for x in years],index=list(range(1,100)))
    for i in years:
        df_stata = import_dta(country=country, year=i)
        df_stata = df_stata[df_stata['sample_999']==1]
        df_stata['ln_m_earnings_euro'] =np.log(df_stata['m_earnings_euro'])
        df_stata = df_stata.groupby(["m_firm_id"]).agg(func)
        df_stata = df_stata.sort_values(by=['ln_m_earnings_euro'], ascending=True)
        df_stata['cum_weight'] = df_stata['m_weight_employees'].cumsum()/df_stata['m_weight_employees'].sum()  
        df_stata['cum_weight'] = df_stata['cum_weight']*100
        for p in df_fin.index:
            df_fin.loc[p,str(i)] = float(df_stata[df_stata['cum_weight']>=p]['ln_m_earnings_euro'].iloc[0])
    df_fin['Firm'] = df_fin[str(years[1])]-df_fin[str(years[0])]
    df_fin['ind_' + str(years[1])] = np.nan
    df_fin['ind_' + str(years[0])] = np.nan
    for i in years:
        df_stata = import_dta(country=country, year=i)
        df_stata = df_stata[df_stata['sample_999']==1]
        df_stata['ln_m_earnings_euro'] =np.log(df_stata['m_earnings_euro'])
        df_stata = df_stata.sort_values(by=['ln_m_earnings_euro'], ascending=True)
        df_stata['cum_weight'] = df_stata['m_weight_employees'].cumsum()/df_stata['m_weight_employees'].sum()  
        df_stata['cum_weight'] = df_stata['cum_weight']*100
        for p in df_fin.index:
            df_fin.loc[p,'ind_' + str(i)] = float(df_stata[df_stata['cum_weight']>=p]['ln_m_earnings_euro'].iloc[0])    
    df_fin['Individual'] = df_fin['ind_' + str(years[1])]-df_fin['ind_' + str(years[0])]

    line_plot_connect(df=df_fin, columns=['Firm'], 
        out_path=(ppj('OUT_FIGURES',fig_name)), xtitle='Percentile of Hourly Wages',
        ytitle='Log Hourly Wage Change',log_scale=False)
    line_plot_connect(df=df_fin, columns=['Individual'], 
        out_path=(ppj('OUT_FIGURES',fig_name_ind)), xtitle='Percentile of Hourly Wages',
        ytitle='Log Hourly Wage Change',log_scale=False)    

cntry_list_east = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary','Latvia', 'Lithuania',
 'Poland',  'Romania', 'Slovakia']

for c in cntry_list_east:
    plot_cum_dist(years=[2006,2014], country=c,suff='')
    plot_cum_dist_firms_ind(years=[2006,2014], country=c,suff='')