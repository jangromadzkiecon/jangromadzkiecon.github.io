import json
import pickle
import sys
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from src.final.plot_code import bar_stacked, line_plot_connect
from bld.project_paths import project_paths_join as ppj
import re

def oaxaca_df_dict(countries, suff):
    ''' Return a dict of dataframes
    with regression results
    '''
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    dict_final = {}
    variables_all = []
    for c in countries:
        dict_final[c] = {}
        df_i = pd.DataFrame(columns=['coefficient', 'se'])
        num=0
        with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[c]) + '_results' + suff + '.txt'), 'r') as f:
            for line in f:
                num+=1
                if num>3:
                    if 'Constant' not in line:
                        if num % 2 == 0:
                            line = line.rstrip('\n')
                            line_list = line.split('\t')
                            # variable name, leave for next loop
                            inx = line_list[0]
                            inx = re.sub('_', '\\_', inx)
                            if inx not in variables_all:
                                variables_all.append(inx)
                            if inx not in ['explained', 'unexplained', 'difference', 'group\\_1', 'group\\_2']:
                                coef = line_list[2]
                            else:
                                coef = line_list[1]
                            coef = re.sub('\*',"", coef)                           
                            df_i.loc[inx,'coefficient'] = float(coef) 
                        else:
                            line = line.rstrip('\n')
                            line_list = line.split('\t')                                
                            df_i.loc[inx,'se'] = line_list[1]
                    else:
                        break
            res_list = []
            with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[c]) + '_results' + suff +'.txt'), 'r') as f:
                for line in f:
                    line = line.rstrip('\n')
                    res_list.append(line)
            df_i.loc['obs','coefficient'] = res_list[-3].split('\t')[1]
            dict_final[c]=df_i
    dict_final['variables'] = variables_all
    return dict_final

def oaxaca_df_dict_deciles(country):
    ''' Return a dict of dataframes
    with regression results
    '''
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    dict_final = {}
    variables_all = []
    deciles=[10,20,30,40,50,60,70,80,90]
    for d in deciles:
        dict_final[d] = {}
        df_i = pd.DataFrame(columns=['coefficient', 'se'])
        num=0
        with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[country]) + '_results_q' + str(d) + '.txt'), 'r') as f:
            for line in f:
                num+=1
                if num>3:
                    if 'Constant' not in line:
                        if num % 2 == 0:
                            line = line.rstrip('\n')
                            line_list = line.split('\t')
                            # variable name, leave for next loop
                            inx = line_list[0]
                            inx = re.sub('_', '\\_', inx)
                            if inx not in variables_all:
                                variables_all.append(inx)
                            if inx not in ['explained', 'unexplained', 'difference', 'group\\_1', 'group\\_2']:
                                coef = line_list[2]
                            else:
                                coef = line_list[1]
                            coef = re.sub('\*',"", coef)                            
                            df_i.loc[inx,'coefficient'] = float(coef) 
                        else:
                            line = line.rstrip('\n')
                            line_list = line.split('\t')                                
                            df_i.loc[inx,'se'] = line_list[1]
                    else:
                        break
            res_list = []
            with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[country]) + '_results_q' + str(d) +'.txt'), 'r') as f:
                for line in f:
                    line = line.rstrip('\n')
                    res_list.append(line)
            df_i.loc['obs','coefficient'] = res_list[-3].split('\t')[1]
            dict_final[d]=df_i
    dict_final['variables'] = variables_all
    return dict_final

def bar_oaxaca(countries, suff):
    ''' Generate stacked bar plots with oaxaca decomposition
    '''

    df_full = pd.DataFrame(index=countries, columns = ['difference', 'explained', 'unexplained'])
    dict_results = oaxaca_df_dict(countries=countries, suff=suff)
    for c in countries:
        df_i  = dict_results[c]
        for i in  ['difference', 'explained', 'unexplained']:
            df_full.loc[c,i] = df_i.loc[i,'coefficient']
    df_full = df_full.sort_values('difference', ascending=True)
    df_full['Total Change'] = df_full['difference']
    df_full['Composition'] = df_full['explained']
    df_full['Wage Structure'] = df_full['unexplained']  
    out_p = ppj('OUT_FIGURES', 'oaxaca_countries' + suff + '.png') 

    bar_stacked(df_bar=df_full[['Composition', 'Wage Structure']], 
    s_diamond=df_full['Total Change'], out_path=out_p, xtitle="Country", 
    ytitle='Variance of Normalized Hourly Wages (Change)',xlab_rot='vertical')
    df_full.to_csv(ppj('OUT_DATA', 'oaxaca_countries' + suff +'.csv'), sep=';')


def plot_oaxaca_deciles(country):
    ''' Generate stacked bar plots with oaxaca decomposition
    '''
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}      
    deciles=[10,20,30,40,50,60,70,80,90]
    df_full = pd.DataFrame(index=deciles, columns =['difference', 'explained', 'unexplained'])
    dict_results = oaxaca_df_dict_deciles(country=country)

    for d in deciles:
        df_i  = dict_results[d]
        for i in  ['difference', 'explained', 'unexplained']:
            df_full.loc[d,i] = df_i.loc[i,'coefficient']
    df_full['Total Change'] = df_full['difference']
    df_full['Composition'] = df_full['explained']
    df_full['Wage Structure'] = df_full['unexplained']
    out_p = ppj('OUT_FIGURES', 'oaxaca_countries_decile_' + country_codes[country] + '.png') 
    line_plot_connect(df=df_full, columns=['Composition', 'Wage Structure','Total Change'], 
        xtitle="Decile", ytitle='Log Hourly Wage Change', out_path=out_p,log_scale=False,
        markers=["D","^","o"],xline=0)
    df_full.to_csv(ppj('OUT_DATA', 'oaxaca_countries_decile_' + country_codes[country] +'.csv'),
    sep=';')    

 


years_1 = [2002,2006,2010,2014]
cntry_list_lim=['Poland', 'Germany', 'France', 'United Kingdom', 'Czech Republic', 'Spain', 'Netherlands', 'Denmark', 'Hungary', 'Romania', 'Croatia', 'Estonia', 'Austria', 'Belgium', 'Italy',
'Sweden', 'Norway', 'Greece']
cntry_list_west = ['Austria', 'Belgium', 'Denmark', 'Finland', 'France','Greece', 'Germany', 'Ireland', 'Italy', 'Netherlands', 'Norway', 'Portugal',
'Spain', 'Sweden', 'Switzerland', 'United Kingdom']

cntry_list_east = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary','Latvia', 'Lithuania',
 'Poland',  'Romania', 'Slovakia']
for c in cntry_list_east:
    plot_oaxaca_deciles(country=c)
for i in ['', '_nopublic','_full']:
    bar_oaxaca(countries=cntry_list_east, suff=i)
