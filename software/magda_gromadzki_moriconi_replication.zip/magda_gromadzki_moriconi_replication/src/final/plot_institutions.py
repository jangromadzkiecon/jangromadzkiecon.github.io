import json
import pickle
import sys
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from bld.project_paths import project_paths_join as ppj
import re
import math

country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
'Sweden': 'se', 'Slovakia': 'sk'}
country_names = {}
for k in country_codes.keys():
    country_names[country_codes[k]]=k


def bar_diamond(s_bar, s_diamond, out_path, xlab_rot, xtitle,ytitle,min_value=0,max_value=False,yint=False):


    fig, ax1 = plt.subplots(figsize=(20, 12))
    ax1.spines["top"].set_visible(False)
    ax1.spines["bottom"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.spines["left"].set_visible(False)

    ind = np.arange(len(s_bar.index))
    x = s_bar.index
    y1 = s_bar
    if y1.max()>2:
        if y1.max()>7:
            interv = math.ceil((max(y1)+1)/7)
            if max_value==False:
                max_ytick = interv * 7
            else:
                max_ytick=max_value
                print(max_ytick)
            if yint==False:
                yint = range(min_value, max_ytick, interv)

            plt.yticks(yint,  fontsize=24,  fontname='Roboto Condensed Light')
            plt.ylim(ymin=min_value, ymax=max_ytick)
        else:
            if yint==False:            
                yint = range(min_value, math.ceil(max(y1))+1)
            plt.yticks(yint,   fontsize=24,  fontname='Roboto Condensed Light')
            plt.ylim(ymin=min_value, ymax=math.ceil(max(y1))+1)
    else:
        plt.yticks(   fontsize=24,  fontname='Roboto Condensed Light')

    plt.bar(ind, y1, 0.75, color='#B6163A', label=s_bar.name)
    start, end = ax1.get_xlim()
    ax1.xaxis.set_ticks(np.arange(start, end, 1))
    plt.xticks(ind, x, rotation=xlab_rot, fontsize=24, fontname='Roboto Condensed Light')
    y2 = s_diamond
    ax1.plot(ind, y2, 'D', color='black', markersize=5, label=s_diamond.name)
    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()
    plt.xlabel(xtitle,fontsize=24,  fontname='Roboto Condensed Light')
    plt.ylabel(ytitle,fontsize=24,  fontname='Roboto Condensed Light') 
    leg = ax1.legend(loc='lower center',bbox_to_anchor=(0.5, -0.35), fontsize=24, frameon=False)
    plt.setp(leg.texts, fontname='Roboto Condensed Light')

    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")
    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()        

    fig.savefig(out_path, dpi=400, bbox_extra_artists=(leg,), bbox_inches='tight')
    fig.savefig(out_path[:-4] + '.pdf', bbox_extra_artists=(leg,), bbox_inches='tight')


def bar_simple(s_bar, out_path, xlab_rot, xtitle,ytitle):


    fig, ax1 = plt.subplots(figsize=(10, 8))
    ax1.spines["top"].set_visible(False)
    ax1.spines["bottom"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.spines["left"].set_visible(False)

    ind = np.arange(len(s_bar.index))
    x = s_bar.index
    y1 = s_bar
    if y1.max()>2:
        if y1.max()>7:
            interv = math.ceil((max(y1)+1)/7)
            max_ytick = interv * 7
            yint = range(0, max_ytick, interv)
            plt.yticks(yint,  fontsize=14,  fontname='Roboto Condensed Light')

        else:
            yint = range(math.floor(min(y1)), math.ceil(max(y1))+1)
            plt.yticks(yint,   fontsize=14,  fontname='Roboto Condensed Light')
    else:
        plt.yticks(   fontsize=14,  fontname='Roboto Condensed Light')

    plt.bar(ind, y1, 0.75, color='#B6163A', label=s_bar.name)

    start, end = ax1.get_xlim()
    ax1.xaxis.set_ticks(np.arange(start, end, 1))
    plt.xticks(ind, x, rotation=xlab_rot, fontsize=14, fontname='Roboto Condensed Light')
    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()
    plt.xlabel(xtitle,fontsize=16,  fontname='Roboto Condensed Light')
    plt.ylabel(ytitle,fontsize=16,  fontname='Roboto Condensed Light') 

    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")
    plt.tight_layout()
    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()    

    fig.savefig(out_path, dpi=400)
    fig.savefig(out_path[:-4] + '.pdf')

def bar_migration():
    ''' Generate bar plots with migration in 2006 and 2014
    '''
    df_2006 = pd.read_csv(ppj('IN_DATA', 'migration_countries_2006.csv'),index_col='country_residence')
    df_2006=  df_2006.fillna(0)
    df_2014 = pd.read_csv(ppj('IN_DATA', 'migration_countries_2014.csv'),index_col='country_residence')
    df_2014=  df_2014.fillna(0)
    df_full = pd.DataFrame(index=list(df_2006.columns), columns = ['2006', '2014']) 
    for c in df_full.index:
        df_full.loc[c,'2006'] = 100*((df_2006[c].astype(float).sum()-float(df_2006.loc[c,c]))/df_2014[c].astype(float).sum())
        df_full.loc[c,'2014'] = 100*((df_2014[c].astype(float).sum()-float(df_2014.loc[c,c]))/df_2014[c].astype(float).sum())
    df_full = df_full.sort_values(by='2014', ascending=False)
    out_p = ppj('OUT_FIGURES', 'migration_countries.png') 
    bar_diamond(s_bar=df_full['2014'], s_diamond=df_full['2006'], out_path=out_p, xtitle="Country", 
    ytitle='Migrant population (% of population)',xlab_rot='vertical')

def bar_gdp_growth():
    ''' Generate stacked bar plots with migration in 2006 and 2014
    '''
    df = pd.read_csv(ppj('IN_DATA', 'gdp_growth_eurostat.csv'))
    df = df.replace({"country": country_names})
    df=df.set_index('country')
    df = df.sort_values(by='2004-2014 average GDP growth',ascending=False)
    out_p = ppj('OUT_FIGURES', 'gdp_growth_countries.png') 
    bar_simple(s_bar=df['2004-2014 average GDP growth'], out_path=out_p, xtitle="Country", 
    ytitle='GDP growth (annual %, 2004-2014 average)',xlab_rot='vertical')

def bar_inv():
    ''' Generate stacked bar plots with migration in 2006 and 2014
    '''
    df = pd.read_csv(ppj('IN_DATA', 'investment_rates_eurostat.csv'))

    df = df.replace({"country": country_names})
    df=df.set_index('country')
    
    df = df.sort_values(by='2004-2014 average Investment share of GDP ',ascending=False)
    out_p = ppj('OUT_FIGURES', 'investment_rates_countries.png') 
    bar_simple(s_bar=df['2004-2014 average Investment share of GDP '], out_path=out_p, xtitle="Country", 
    ytitle='Investments (% share of GDP, 2004-2014 average)',xlab_rot='vertical')


def bar_min_wage():
    df_nominal = pd.read_csv(ppj('IN_DATA', 'min_wage_eurostat.csv'))
    df_nominal = df_nominal.replace({"country": country_names})
    df_nominal=df_nominal.set_index('country')
    df_nominal = df_nominal.sort_values(by='2014', ascending=False)
    df_kaitz = pd.read_csv(ppj('IN_DATA', 'min_wage_kaitz_eurostat.csv'))
    df_kaitz = df_kaitz.replace({"country": country_names})
    df_kaitz=df_kaitz.set_index('country')
    df_kaitz = df_kaitz.sort_values(by='2014', ascending=False)
    out_p1 = ppj('OUT_FIGURES', 'min_wage_euro_countries.png') 
    out_p2 = ppj('OUT_FIGURES', 'min_wage_kaitz_countries.png') 
    bar_diamond(s_bar=df_nominal['2014'], s_diamond=df_nominal['2006'], out_path=out_p1, xtitle="Country", 
    ytitle='Monthly minimum wage (euro)',xlab_rot='vertical',min_value=0, max_value=400,yint=range(0, 500, 100))
    bar_diamond(s_bar=df_kaitz['2014'], s_diamond=df_kaitz['2006'], out_path=out_p2, xtitle="Country", 
    ytitle='Minimum wage (% of average earnings)',xlab_rot='vertical',min_value=0, max_value=50,yint=range(0, 60, 10))    
bar_migration()
bar_gdp_growth()
bar_inv()
bar_min_wage()