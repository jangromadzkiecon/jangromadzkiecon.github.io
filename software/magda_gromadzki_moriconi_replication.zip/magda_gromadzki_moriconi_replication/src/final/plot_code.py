import json
import pickle
import sys
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from collections import OrderedDict
from matplotlib.ticker import ScalarFormatter

# Take negative and positive data apart and cumulate
def get_cumulated_array(data, **kwargs):
    cum = data.clip(**kwargs)
    cum = np.cumsum(cum, axis=0)
    d = np.zeros(np.shape(data))
    d[1:] = cum[:-1]
    return d

def line_plot_multiple(df, columns, out_path,xtitle,ytitle):

    tableau20 = [(31, 119, 180), (174, 199, 232), (255, 127, 14), (255, 187, 120),
                 (44, 160, 44), (152, 223, 138), (214, 39, 40), (255, 152, 150),
                 (148, 103, 189), (197, 176, 213), (140, 86, 75), (196, 156, 148),
                 (227, 119, 194), (247, 182, 210), (127, 127, 127), (199, 199, 199),
                 (188, 189, 34), (219, 219, 141), (23, 190, 207), (158, 218, 229)]

    marker_list = ["+", "o", "x",  "v", "8", "s", "D", "h", "*"]
    linestyles = OrderedDict(
            [('solid',               (0, ())),
             ('dotted',              (0, (1, 5))),
             ('densely dotted',      (0, (1, 1))),
             ('dashed',              (0, (5, 5))),
             ('densely dashed',      (0, (5, 1))),
    
             ('dashdotted',          (0, (3, 5, 1, 5))),
             ('densely dashdotted',  (0, (3, 1, 1, 1))),
    
             ('dashdotdotted',         (0, (3, 5, 1, 5, 1, 5))),
             ('densely dashdotdotted', (0, (3, 1, 1, 1, 1, 1)))])


    for i in range(len(tableau20)):
        r, g, b = tableau20[i]
        tableau20[i] = (r / 255., g / 255., b / 255.)
    df_sel = df[columns]
    df_sel = df_sel.loc[:, (df_sel != 0).any(axis=0)]
    df_sel=df_sel.dropna(axis=1,how='all')
    columns = list(df_sel.columns)

    plt.figure(figsize=(12, 7))

    ax = plt.subplot(111)
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(True)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(True)

    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()
    plt.ylim(np.nanmin(df_sel.values)-0.025* np.nanmin(df_sel.values), np.nanmax(df_sel.values)+0.025* np.nanmax(df_sel.values))
    plt.xlim(min(df_sel.index), max(df_sel.index))

    plt.xlabel(xtitle,fontsize=24,  fontname='Roboto Condensed Light')
    plt.ylabel(ytitle,fontsize=24,  fontname='Roboto Condensed Light')
    plt.xticks(np.arange(min(df_sel.index), max(df_sel.index)+1, 4), fontsize=20,  fontname='Roboto Condensed Light')
    if np.nanmax(df_sel.values)>2:
        if np.nanmax(df_sel.values)>7:
            interv = math.ceil((np.nanmax(df_sel.values)+1)/7)
            max_ytick = interv * 7
            yint = range(math.floor(np.nanmin(df_sel.values)), max_ytick, interv)
            plt.yticks(yint,  fontsize=20,  fontname='Roboto Condensed Light')

        else:
            yint = range(math.floor(np.nanmin(df_sel.values)), math.ceil(np.nanmax(df_sel.values))+1)
            plt.yticks(yint,  fontsize=20,  fontname='Roboto Condensed Light')
    else:
        plt.yticks( fontsize=20,  fontname='Roboto Condensed Light')

    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")

    for rank, column in enumerate(columns):

        plt.plot(
                df_sel[column],label=column,
                lw=2.5, color='#B6163A', linestyle=linestyles[list(linestyles.keys())[rank]])

        print(df_sel[column])
        df_nona=df_sel[np.isfinite(df_sel[column])]
        y_pos = df_sel.loc[ max(df_nona.index),column]
    plt.legend(frameon=False, loc='lower center', bbox_to_anchor=(0.5, -0.5), ncol=3, fontsize=20, handlelength=4)
    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()
    plt.savefig(out_path, bbox_inches="tight",  dpi=400)
    plt.savefig(out_path[:-4] + '.pdf', bbox_inches="tight")

def line_plot_connect(df, columns, out_path,xtitle,ytitle,log_scale=False,markers=False,xline=None):

    tableau20 = [ (221, 117, 142),(186, 23, 54), (0, 0, 0), (255, 187, 120),
                 (44, 160, 44), (152, 223, 138), (214, 39, 40), (255, 152, 150),
                 (148, 103, 189), (197, 176, 213), (140, 86, 75), (196, 156, 148),
                 (227, 119, 194), (247, 182, 210), (127, 127, 127), (199, 199, 199),
                 (188, 189, 34), (219, 219, 141), (23, 190, 207), (158, 218, 229)]

    marker_list = ["+", "o", "x",  "v", "8", "s", "D", "h", "*"]

    for i in range(len(tableau20)):
        r, g, b = tableau20[i]
        tableau20[i] = (r / 255., g / 255., b / 255.)
    df_sel = df[columns]
    df_sel = df_sel.loc[:, (df_sel != 0).any(axis=0)]
    df_sel=df_sel.dropna(axis=1,how='all')
    columns = list(df_sel.columns)

    plt.figure(figsize=(12, 7))

    ax = plt.subplot(111)
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(True)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(True)

    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()

    plt.xlim(0, 100)
    plt.xlabel(xtitle,fontsize=24,  fontname='Roboto Condensed Light')
    plt.ylabel(ytitle,fontsize=24,  fontname='Roboto Condensed Light')
    plt.xticks([0,20,40,60,80,100], fontsize=16,  fontname='Roboto Condensed Light')
    if log_scale==True:
        ax.set_yscale('log', basey=2)
        plt.ylim( (pow(2,-2),pow(2,6)) )
        for axis in [ax.yaxis]:
            formatter = ScalarFormatter()
            formatter.set_scientific(False)
            axis.set_major_formatter(formatter)
        ax.tick_params(axis='y', labelsize=16)
    else:
        plt.ylim(-0.2, 1)
        plt.yticks([-0.2,0,0.2,0.4,0.6,0.8,1],  fontsize=20,  fontname='Roboto Condensed Light')

    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")

    for rank, column in enumerate(columns):

        if markers==False:
            plt.plot(
                    df_sel[column],label=column,
                    lw=2.5, color=tableau20[rank],marker="D",markersize=7)
        else:
            plt.plot(
                    df_sel[column],label=column,
                    lw=2.5, color=tableau20[rank],marker=markers[rank],markersize=7)            
    plt.legend(frameon=False, loc='lower center', bbox_to_anchor=(0.5, -0.35), ncol=2, fontsize=20, handlelength=4)
    if xline!=None:
        print('xd')
        plt.axhline(y=xline, linestyle='dashed',color='k')
    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()
    plt.savefig(out_path, bbox_inches="tight",  dpi=400)
    plt.savefig(out_path[:-4] + '.pdf', bbox_inches="tight")

def bar_diamond(s_bar, s_diamond, out_path):


    fig, ax1 = plt.subplots(figsize=(10, 8))
    ax1.spines["top"].set_visible(False)
    ax1.spines["bottom"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.spines["left"].set_visible(False)

    ind = np.arange(len(s_bar.index))
    x = s_bar.index
    y1 = s_bar
    if y1.max()>2:
        if y1.max()>7:
            interv = math.ceil((max(y1)+1)/7)
            max_ytick = interv * 7
            yint = range(math.floor(min(y1)), max_ytick, interv)
            plt.yticks(yint,  fontsize=14,  fontname='Roboto Condensed Light')

        else:
            yint = range(math.floor(min(y1)), math.ceil(max(y1))+1)
            plt.yticks(yint,   fontsize=14,  fontname='Roboto Condensed Light')
    else:
        plt.yticks(   fontsize=14,  fontname='Roboto Condensed Light')

    plt.bar(ind, y1, 0.75, color='#B6163A')

    start, end = ax1.get_xlim()
    ax1.xaxis.set_ticks(np.arange(start, end, 1))
    plt.xticks(ind, x, rotation='vertical', fontsize=14, fontname='Roboto Condensed Light')
    y2 = s_diamond

    ax1.plot(ind, y2, 'D', color='black', markersize=5)
    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()
    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")
    plt.tight_layout()
    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()    
    fig.savefig(out_path, dpi=400)
    fig.savefig(out_path[:-4] + '.pdf')

def bar_stacked(df_bar, s_diamond, out_path,xtitle,ytitle,xlab_rot):
    ''' Generate stacked bar plot
    '''
    tableau_ibs = [(211, 210, 210), (182, 22, 58),   (195, 82, 91), (123, 121, 121),
                 (207, 121, 44), (167, 165, 166), (222, 160, 157),(79, 76, 77),
                 (238, 205, 199)]
    for i in range(len(tableau_ibs)):
        r, g, b = tableau_ibs[i]
        tableau_ibs[i] = (r / 255., g / 255., b / 255.)
    fig, ax1 = plt.subplots(figsize=(20, 10))
    ax1.spines["top"].set_visible(False)
    ax1.spines["bottom"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.spines["left"].set_visible(False)
    ind = np.arange(len(s_diamond.index))
    x = s_diamond.index
    neg_sums=[]
    pos_sums=[]
    row_lists = df_bar.values.tolist()
    for row in row_lists:
        pos_sums.append(sum([i for i in row if i >= 0]))
        neg_sums.append(sum([i for i in row if i < 0]))
    if max([abs(max(pos_sums)),abs(min(neg_sums))])>2:
        if max([abs(max(pos_sums)),abs(min(neg_sums))])>7:
            interv = math.ceil((max([abs(max(pos_sums)),abs(min(neg_sums))])+1)/7)
            max_ytick = interv * 7
            yint = range(math.floor(min(neg_sums)), math.ceil(max(pos_sums)), interv)
            plt.yticks(yint,  fontsize=25,  fontname='Roboto Condensed Light')

        else:
            yint = range(math.floor(min(neg_sums)), math.ceil(max(pos_sums))+1)
            plt.yticks(yint,   fontsize=25,  fontname='Roboto Condensed Light')
    else:
        plt.yticks(   fontsize=25,  fontname='Roboto Condensed Light')
    plt.xlabel(xtitle,fontsize=28,  fontname='Roboto Condensed Light')
    plt.ylabel(ytitle,fontsize=28,  fontname='Roboto Condensed Light')    
    columns_names_list = list(df_bar.columns)
    column_values_list = []
    for c in df_bar.columns:
        list_val = df_bar[c].tolist()
        column_values_list.append(list_val)
    data = np.array(column_values_list)
    data_shape = np.shape(data)
    cumulated_data = get_cumulated_array(data, min=0)
    cumulated_data_neg = get_cumulated_array(data, max=-0.00000000000001)
    row_mask = (data<0)
    cumulated_data[row_mask] = cumulated_data_neg[row_mask]
    data_stack = cumulated_data
    for i in np.arange(0, data_shape[0]):
        plt.bar(np.arange(data_shape[1]), data[i], bottom=data_stack[i], color=tableau_ibs[i],lw=2.5, label=columns_names_list[i])    

    start, end = ax1.get_xlim()
    ax1.xaxis.set_ticks(np.arange(start, end, 1))
    plt.xticks(ind, x, rotation=xlab_rot, fontsize=25, fontname='Roboto Condensed Light')
    y2 = s_diamond

    plt.plot(ind, y2, 'D', color='black', markersize=5, label='Total Change')

    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()

    leg = ax1.legend(loc='lower center',bbox_to_anchor=(0.5, -0.6), fontsize=25, frameon=False)
    plt.setp(leg.texts, fontname='Roboto Condensed Light')
    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")

    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()    
    fig.savefig(out_path, dpi=400, bbox_extra_artists=(leg,), bbox_inches='tight')
    fig.savefig(out_path[:-4] + '.pdf', bbox_extra_artists=(leg,), bbox_inches='tight')




def scatter_plot(x,y,name,x_name,y_name,labels):
    plt.figure(figsize=(12, 9))
    plt.scatter(x, y, alpha=0.5, color='#B6163A' )
    plt.xlabel(x_name, fontname='Roboto Condensed Light')
    plt.ylabel(y_name, fontname='Roboto Condensed Light')
    ax = plt.subplot(111)
    for i, txt in enumerate(labels):
        yposl = (y[i]*(1+(0.05/(abs(min(y)-max(y))))))
        xposl = (x[i]*(1+(0.05/(abs(min(y)-max(y))))))
        ax.annotate(txt, (xposl,yposl))

    plt.tick_params(axis="both", which="both", bottom="off", top="off",
                    labelbottom="on", left="off", right="off", labelleft="on")
    if x.max()>2:
        if x.max()>7:
            interv = math.ceil((max(x)+1)/7)
            max_xtick = interv * 7
            xint = range(math.floor(min(x)), max_xtick, interv)
            plt.xticks(xint,  fontname='Roboto Condensed Light')
        else:
            xint = range(math.floor(min(x)), math.ceil(max(x))+1)
            plt.xticks(xint,  fontname='Roboto Condensed Light')
    else:
        plt.xticks(   fontsize=14,  fontname='Roboto Condensed Light')
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    plt.plot(x,p(x),  color='#B6163A')
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    plt.savefig(name, bbox_inches="tight")
    return 'figure'
