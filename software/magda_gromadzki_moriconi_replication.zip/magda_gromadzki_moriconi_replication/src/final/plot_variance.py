import json
import pickle
import sys
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from src.final.plot_code import line_plot_multiple
from bld.project_paths import project_paths_join as ppj

def plot_change_time(years, countries, measure, industry, suffix):
    if industry=='all':
        df_name = measure + '_summary' + suffix + '.csv'
        fig_name =  measure + '_summary' + suffix + '.png'
    else: 
        df_name = measure + '_' + industry + '_summary' + suffix + '.csv' 
        fig_name = measure + '_' + industry + '_summary' + suffix + '.png'           
    df_ = pd.read_csv(ppj('OUT_DATA',df_name),sep=';', index_col=0)
    line_plot_multiple(df=df_, columns=countries, out_path=(ppj('OUT_FIGURES',fig_name)), 
    	xtitle="Year",ytitle='Variance of log hourly wages')




years_1 = [2002,2006,2010,2014]
cntry_list_lim=['Poland', 'Germany', 'France', 'United Kingdom', 'Czech Republic', 'Spain', 'Netherlands', 'Denmark', 'Hungary', 'Romania', 'Croatia', 'Estonia', 'Austria', 'Belgium', 'Italy',
'Sweden', 'Norway', 'Greece']
cntry_list_west = ['Austria', 'Belgium', 'Denmark', 'Finland', 'France','Greece', 'Germany', 'Ireland', 'Italy', 'Netherlands', 'Norway', 'Portugal',
'Spain', 'Sweden', 'Switzerland', 'United Kingdom']

cntry_list_east = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary','Latvia', 'Lithuania',
 'Poland',  'Romania', 'Slovakia']
cntry_west=['Netherlands', 'Norway', 'Portugal', 'Sweden']

plot_change_time(years=years_1, countries=cntry_list_east, measure='variance', industry='all', suffix='_full')
plot_change_time(years=years_1, countries=cntry_list_east, measure='variance', industry='all', suffix='')
plot_change_time(years=years_1, countries=cntry_west, measure='variance', industry='all', suffix='_west')