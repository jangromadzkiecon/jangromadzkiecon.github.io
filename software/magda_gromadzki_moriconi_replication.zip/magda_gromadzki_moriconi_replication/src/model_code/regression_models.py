import numpy as np
#from sklearn.linear_model import LinearRegression
from scipy import sparse
from sklearn.utils.extmath import safe_sparse_dot
import statsmodels.api as sm
import pandas as pd
from statsmodels.discrete.discrete_model import Logit
from bld.project_paths import project_paths_join as ppj
from scipy.stats import chi2
import scipy
from src.model_code.ineq_indices import variance_weighted

def _rescale_data(X, y, sample_weight):
    """Rescale data so as to support sample_weight"""
    n_samples = X.shape[0]
    #print(sample_weight)
    sample_weight = sample_weight * np.ones(n_samples)
    sample_weight = np.sqrt(sample_weight)
    sw_matrix = sparse.dia_matrix((sample_weight, 0),
                                  shape=(n_samples, n_samples))
    X = safe_sparse_dot(sw_matrix, X.astype(float))
    y = safe_sparse_dot(sw_matrix, y.astype(float))
    return X, y


class ols_regression:
    ''' A class for calling different types of OLS results
    '''
    def __init__(self, df, X_vars, y_var, weight_var):    
        for i in X_vars:
            df[i] = df[i].astype(float)
            num_nan = df[i].isnull().sum()
        df = df.dropna(subset = X_vars + [y_var])
        #print(df[X_vars].dtypes)
        y = df[y_var]
        X = df[X_vars]
        X = sm.add_constant(X)
        labels = list(X.columns)
        #print(X)
        X_mod, y = _rescale_data(X, y, df[weight_var])
        model = sm.OLS(y,X_mod)
        model.data.xnames=labels
        self.endog_var = y_var
        self.weight = df[weight_var]
        self.results = model.fit()
        #print(self.results.summary())
        self.var_names = labels
        self.df = df
        # df doesn't include constant so we have to
        # separately provide X matrix
        self.X = X

    def predict_y(self):
        ''' Predicts dependent variable
        '''
        ypred = self.results.predict(self.X[self.var_names]) 
        return ypred

    def residuals(self):
        ''' Returns df with one additional column with residuals
        '''
        df_ = self.df
        df_['predicted'] = self.predict_y()
        df_['residuals'] = df_['predicted']-df_[self.endog_var]
        return df_

    def r_squared(self):
        ''' Returns R-squared of the results
        '''
        pred_y = self.predict_y()
        y_obs = self.df[self.endog_var]
        rsq = variance_weighted(x=pred_y, weight=self.weight)/variance_weighted(x=y_obs, weight=self.weight)
        #print(rsq)
        return rsq

    def param_var(self,var):
        ''' Returns coefficient of a given variable
        '''
        pos = self.var_names.index(var)
        coef = self.results.params[pos]
        return coef




