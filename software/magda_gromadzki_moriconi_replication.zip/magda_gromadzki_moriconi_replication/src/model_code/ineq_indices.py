import numpy as np
import pandas as pd 

def mean_weighted(x, weight):
    x_w = x*weight
    mean_w =  float(x_w.sum() / weight.sum())
    return mean_w

def product_weighted(x, weight):
    x_w = x**weight
    prod = x_w.prod()
    prod_w = prod**(1./weight.mean())
    return prod_w

def variance_weighted(x, weight):
    x_mean = mean_weighted(x=x,weight=weight)
    x_var = (x-x_mean)**2.
    x_var_w = x_var*weight
    variance = x_var_w.sum() / (weight.sum()-(weight.sum()/len(weight)))
    return variance

def theil_t(x,weight):
    ''' Generate Theil T measure
    of inequality
    https://en.wikipedia.org/wiki/Theil_index
    '''
    x=x[x>0]
    mean_x_col = mean_weighted(x, weight)
    x_norm = x/mean_x_col
    log_x_norm=np.log(x_norm)
    product_weighted = x_norm*log_x_norm*weight
    theil_t_ix = float(product_weighted.sum()/weight.sum())
    return theil_t_ix

def dispersion_quantiles(df_in,earnings, weight,nom,denom):
    ''' Measure of dispersion
    '''
    df_in = df_in[[earnings, weight]]
    df_in = df_in.sort_values(by=[earnings], ascending=True)
    df_in['cum_weight'] = df_in[weight].cumsum()/df_in[weight].sum()
    nom_val =  float(df_in[df_in['cum_weight']>=nom][earnings].iloc[0])
    denom_val = float(df_in[df_in['cum_weight']>=denom][earnings].iloc[0])
    return nom_val/denom_val

def share_quantiles(df_in,earnings, weight,quant):
    ''' Measure of dispersion
    '''
    df_in = df_in[[earnings, weight]]
    df_in = df_in.sort_values(by=[earnings], ascending=False)
    df_in['cum_weight'] = df_in[weight].cumsum()/df_in[weight].sum()
    df_q = df_in[df_in['cum_weight']<=quant]
    q_share = float(df_q[earnings].sum()/df_in[earnings].sum())
    return q_share

def atkinson(x, weight, epsilon):
    ''' Generate Atkinson measure of inequality
    http://www.fao.org/docs/up/easypol/451/welfare_measures_inequa_atkinson_050en.pdf
    '''
    if epsilon!=1:
        if epsilon<0:
            raise ValueError('epsilon cannot be smaller than 0')
        else:
            mean_x = mean_weighted(x=x, weight=weight)
            x_ede_df = x**(1.-epsilon)
            mean_x_ede = mean_weighted(x=x_ede_df, weight=weight)
            x_ede = mean_x_ede**(1./(1.-epsilon))
    else:
        x_ede = product_weighted(x=x,weight=weight)**(1./len(x))
    atk = 1. - (x_ede/mean_weighted(x=x, weight=weight))
    return atk

def gini(x, weight):
    # The rest of the code requires numpy arrays.
    x = np.asarray(x)
    if weight is not None:
        weight = np.asarray(weight)
        sorted_indices = np.argsort(x)
        sorted_x = x[sorted_indices]
        sorted_w = weight[sorted_indices]
        # Force float dtype to avoid overflows
        cumw = np.cumsum(sorted_w, dtype=float)
        cumxw = np.cumsum(sorted_x * sorted_w, dtype=float)
        return (np.sum(cumxw[1:] * cumw[:-1] - cumxw[:-1] * cumw[1:]) / 
                (cumxw[-1] * cumw[-1]))
    else:
        sorted_x = np.sort(x)
        n = len(x)
        cumx = np.cumsum(sorted_x, dtype=float)
        # The above formula, with all weights equal to 1 simplifies to:
        return (n + 1 - 2 * np.sum(cumx) / cumx[-1]) / n


