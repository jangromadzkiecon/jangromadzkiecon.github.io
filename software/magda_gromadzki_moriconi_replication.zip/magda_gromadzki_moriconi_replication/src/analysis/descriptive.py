"""
Descriptive statistics for SES data
"""


import sys
import json
import logging
import pickle
import numpy as np
import pandas as pd
from bld.project_paths import project_paths_join as ppj
from src.data_management.read_data import import_dta 

def mean_weighted(df,col_name,weight_col):
    df['weighted_col'] = df[col_name]*df[weight_col]
    mean_w =  df['weighted_col'].sum() / df[weight_col].sum()
    return mean_w

def share_weighted(df,col_name,value,weight_col):
    df_select = df[df[col_name]==value]
    share_w =  100*df_select[weight_col].sum() / df[weight_col].sum()
    return share_w

def miss_share(df,col_name,weight_col):
    df_nomiss = df.dropna(subset=[col_name])
    sharemiss = 100 - (100*df_nomiss[weight_col].sum() / df[weight_col].sum())
    return sharemiss

def country_statistics(df):
    ''' Generate a dict of summary statistics for a SES dataframe
    '''
    country_stats = {}
    country_stats['number of observations'] = '{:,}'.format(len(df)).replace(',', ' ')
    country_stats['number of firms'] = '{:,}'.format(len(df['m_firm_id'].unique())).replace(',', ' ')
    country_stats['mean of hourly earnings (euro)'] = str("%.2f" % mean_weighted(df=df,col_name='m_earnings_euro', weight_col='m_weight_employees'))
    country_stats['age: 14-29 years (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_age_ag3',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['age: 30-49 years (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_age_ag3',value=2,weight_col='m_weight_employees')) + ' \\%'
    country_stats['age: 50 years or more (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_age_ag3',value=3,weight_col='m_weight_employees')) + ' \\%'
    country_stats['education: primary (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_educ_ag',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['education: secondary (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_educ_ag',value=2,weight_col='m_weight_employees')) + ' \\%'
    country_stats['education: tertiary (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_educ_ag',value=3,weight_col='m_weight_employees')) + ' \\%'
    country_stats['gender: female (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_gender',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE: manufacturing and construction (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='nace_manu_constr',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE: market services (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='nace_mark_serv',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE: non-market services (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='nace_nonmark_serv',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: A (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="A",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: B (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="B",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: C (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="C",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: D+E (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="D_E",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: F (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="F",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: G (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="G",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: H+J (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="H_J",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: I (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="I",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: K (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="K",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: L+M+N (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="L_M_N",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: O (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="O",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: P (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="P",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: Q (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="Q",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: R+S (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="R_S",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: T (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="T",weight_col='m_weight_employees')) + ' \\%'
    country_stats['NACE 2.0: U (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_nace2_uni',value="U",weight_col='m_weight_employees')) + ' \\%'
    country_stats['occupation: highly skilled non-manual (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['occupation: lower skilled non-manual (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation',value=2,weight_col='m_weight_employees')) + ' \\%'
    country_stats['occupation: skilled manual (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation',value=3,weight_col='m_weight_employees')) + ' \\%'
    country_stats['occupation: elementary occupation (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation',value=4,weight_col='m_weight_employees')) + ' \\%'
    country_stats['occupation: ISCO 1 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['occupation: ISCO 2 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=2,weight_col='m_weight_employees')) + ' \\%'    
    country_stats['occupation: ISCO 3 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=3,weight_col='m_weight_employees')) + ' \\%'    
    country_stats['occupation: ISCO 4 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=4,weight_col='m_weight_employees')) + ' \\%'    
    country_stats['occupation: ISCO 5 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=5,weight_col='m_weight_employees')) + ' \\%'    
    country_stats['occupation: ISCO 6 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=6,weight_col='m_weight_employees')) + ' \\%'    
    country_stats['occupation: ISCO 7 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=7,weight_col='m_weight_employees')) + ' \\%'    
    country_stats['occupation: ISCO 8 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=8,weight_col='m_weight_employees')) + ' \\%'    
    country_stats['occupation: ISCO 9 (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_occupation_1d',value=9,weight_col='m_weight_employees')) + ' \\%'    

    country_stats['public sector (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='m_pubcontr',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['industry-level agreements (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='industry_agreement',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['firm-level agreements (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='firm_agreement',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['fixed contract (\\% share)'] = str("%.2f" % share_weighted(df=df,col_name='fixed_contract',value=1,weight_col='m_weight_employees')) + ' \\%'
    country_stats['missing values: age (\\% share)'] = str("%.2f" % miss_share(df=df,col_name='m_age_ag3',weight_col='m_weight_employees')) + ' \\%'
    country_stats['missing values: hourly earnings (\\% share)'] = str("%.2f" % miss_share(df=df,col_name='m_earnings_euro',weight_col='m_weight_employees')) + ' \\%'
    country_stats['missing values: education (\\% share)'] = str("%.2f" % miss_share(df=df,col_name='m_educ_ag',weight_col='m_weight_employees')) + ' \\%'
    country_stats['missing values: gender (\\% share)'] = str("%.2f" % miss_share(df=df,col_name='m_gender',weight_col='m_weight_employees')) + ' \\%'
    return country_stats

def row_descriptive(variable,stats_dict,countries,year,exclude):
    row =str(year) 
    for c in countries:
        if exclude==True:
            if year==2002:
                if c in ['Estonia', 'Hungary', 'Latvia', 'Sweden', 'Portugal']:
                    row += ' & '
                else:
                    row += ' & ' + stats_dict[c + str(year)][variable]
            else:
                row += ' & ' + stats_dict[c + str(year)][variable]
        else:
            row += ' & ' + stats_dict[c + str(year)][variable]
    row+='\\\ \n'
    return row

def desc_table(countries, years, suffix):
    stats_dict={}
    header = 'year'
    tab_cols = 'l'
    num_header=1
    for c in countries:
        header+= ' & ' + c
        tab_cols+='c'     
        num_header+=1   
        for y in years:
            df_stata = import_dta(country=c, year=y)
            df_stata = df_stata[df_stata['sample_999']==1] 
            stats_dict[c + str(y)] = country_statistics(df_stata)
    header += '\\\ \n'
    # the keys are the same for all countries and years
    list_tables = stats_dict[c + str(y)].keys()
    with open(ppj('OUT_TABLES','descriptive_tables' + suffix + '.tex'), 'w') as fw:
        for i in list_tables:
            fw.write('\\begin{table}[H]\\caption{' + i + '}\n \\centering\n')
            fw.write('\\resizebox{0.9\\textwidth}{!}{')
            fw.write('\\begin{tabular}{' + tab_cols + '}\n')
            fw.write(header)
            fw.write('\\hline \n')
            for y in years:
                fw.write(row_descriptive(variable=i,stats_dict=stats_dict,countries=countries,year=y,exclude=False))
            fw.write('\\multicolumn{'+str(num_header)+'}{l}{\\footnotesize \\textit{Data: European Structure of Earnings Survey.}}\\\ \n')
            fw.write('\\end{tabular}} \n')
            fw.write('\\end{table} \n')            
    with open(ppj('OUT_TABLES','descriptive_table_observations' + suffix + '.tex'), 'w') as fw2: 
        fw2.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw2.write(header)
        fw2.write('\\hline \n')
        for y in years:
            fw2.write(row_descriptive(variable='number of observations',stats_dict=stats_dict,countries=countries,year=y,exclude=True))    
        fw2.write('\\end{tabular} \n')   
    with open(ppj('OUT_TABLES','descriptive_table_firms' + suffix + '.tex'), 'w') as fw3: 
        fw3.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw3.write(header)
        fw3.write('\\hline \n')
        for y in years:
            fw3.write(row_descriptive(variable='number of firms',stats_dict=stats_dict,countries=countries,year=y,exclude=True))    
        fw3.write('\\end{tabular} \n') 
    with open(ppj('OUT_TABLES','descriptive_table_mean_hourly_earnings' + suffix + '.tex'), 'w') as fw4: 
        fw4.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw4.write(header)
        fw4.write('\\hline \n')
        for y in years:
            fw4.write(row_descriptive(variable='mean of hourly earnings (euro)',stats_dict=stats_dict,countries=countries,year=y,exclude=True))    
        fw4.write('\\multicolumn{'+str(num_header)+'}{l}{\\footnotesize \\textit{Data: European Structure of Earnings Survey.}}\\\ \n')
        fw4.write('\\end{tabular} \n')    

countries_list = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Netherlands', 'Norway', 'Poland', 'Portugal', 'Romania', 'Sweden', 'Slovakia']

countries_cee = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Poland', 'Romania', 'Slovakia']
countries_west = ['Netherlands', 'Norway', 'Portugal', 'Sweden']
desc_table(countries=countries_cee,years=[2002,2006,2010,2014], suffix="")
desc_table(countries=countries_west,years=[2002,2006,2010,2014], suffix="_west")