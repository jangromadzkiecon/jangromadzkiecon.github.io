"""
Generating latex tables based on Stata outreg2 outputs
"""

import sys
import json
import logging
import pickle
import numpy as np
import pandas as pd
from bld.project_paths import project_paths_join as ppj
import re
from src.data_management.read_data import import_dta 
from src.model_code.regression_models  import ols_regression 
from src.model_code.ineq_indices import variance_weighted, atkinson, gini


def predicted_series(model, df, endog_var, exog_vars, weight_var):
    ''' Return a predicted series of an endog var
    '''
    regression_class = ols_regression(df=df, X_vars=exog_vars, y_var=endog_var, weight_var=weight_var)

def variance_residuals_dict(countries,years):
    ''' Generate dict of residual variance
    and between / within 
    '''
    vars_ind = ['tertiary_ed', 'secondary_ed', 'middle_age', 'old_age', 'female',
    'one_fouryearsexp', 'five_nineyearsexp', 'longexp', 'occ_1d_dum_2.0', 'occ_1d_dum_3.0',
    'occ_1d_dum_4.0','occ_1d_dum_5.0','occ_1d_dum_6.0','occ_1d_dum_7.0','occ_1d_dum_8.0','occ_1d_dum_9.0']
    vars_all = ['tertiary_ed', 'secondary_ed', 'middle_age', 'old_age', 'female',
    'one_fouryearsexp', 'five_nineyearsexp', 'longexp', 'occ_1d_dum_2.0', 'occ_1d_dum_3.0',
    'occ_1d_dum_4.0','occ_1d_dum_5.0','occ_1d_dum_6.0','occ_1d_dum_7.0','occ_1d_dum_8.0','occ_1d_dum_9.0','m_pubcontr',
    'nace2_uni_dum_C', 'nace2_uni_dum_D_E','nace2_uni_dum_F','nace2_uni_dum_G','nace2_uni_dum_H_J',
    'nace2_uni_dum_I','nace2_uni_dum_K','nace2_uni_dum_L_M_N','nace2_uni_dum_O','nace2_uni_dum_P',
    'nace2_uni_dum_Q','nace2_uni_dum_R_S',
    'tenure_below_two_firm_share', 'old_age_firm_share', 'tertiary_ed_firm_share', 'female_firm_share']
    vars_nopeers = ['tertiary_ed', 'secondary_ed', 'middle_age', 'old_age', 'female',
    'one_fouryearsexp', 'five_nineyearsexp', 'longexp', 'occ_1d_dum_2.0', 'occ_1d_dum_3.0',
    'occ_1d_dum_4.0','occ_1d_dum_5.0','occ_1d_dum_6.0','occ_1d_dum_7.0','occ_1d_dum_8.0','occ_1d_dum_9.0',
    'nace2_uni_dum_C', 'nace2_uni_dum_D_E','nace2_uni_dum_F','nace2_uni_dum_G','nace2_uni_dum_H_J',
    'nace2_uni_dum_I','nace2_uni_dum_K','nace2_uni_dum_L_M_N','nace2_uni_dum_O','nace2_uni_dum_P',
    'nace2_uni_dum_Q','nace2_uni_dum_R_S', 'm_pubcontr']

    df_tertiary_param = pd.DataFrame(columns=countries, index=years)
    rsquared_c_columns = []
    for c in countries:
        for i in ['_ind', '_firm', '_fixed_firm']:
            rsquared_c_columns.append(c+i)
    df_rsquared = pd.DataFrame(columns=rsquared_c_columns, index=years)
    dict_measures = {}
    for i in years:
        dict_measures[i]={}
        for c in countries:
            print(i)
            print(c)
            if c in ['Estonia', 'Hungary', 'Latvia', 'Sweden'] and i==2002:
                pass
            else:
                dict_measures[i][c]={}
                df = import_dta(country=c, year=i)
                df = df[df['sample_999']==1]
                df = df[df['m_weight_employees']>0.]
                df = pd.get_dummies(df, columns=['m_occupation_1d', 'm_nace2_uni'], prefix=['occ_1d_dum', 'nace2_uni_dum'])
                print(df.columns)
                # regression results with individual characteristics only
                reg_class_ind = ols_regression(df=df, X_vars=vars_ind, y_var='ln_nwage', weight_var='m_weight_employees')
                df_rsquared.loc[i,c+'_ind'] = reg_class_ind.r_squared()
                # regression results including firm
                reg_class_ind_firm = ols_regression(df=df, X_vars=vars_all, y_var='ln_nwage', weight_var='m_weight_employees')
                df_rsquared.loc[i,c+'_firm'] = reg_class_ind_firm.r_squared()
                # regression including firm but no peers
                reg_class_ind_firm_nopeers = ols_regression(df=df, X_vars=vars_nopeers, y_var='ln_nwage', weight_var='m_weight_employees')
                print(reg_class_ind_firm_nopeers.results.summary())
                df_tertiary_param.loc[i,c] = reg_class_ind_firm_nopeers.param_var('tertiary_ed')
                # get a column with residuals
                df = reg_class_ind_firm.residuals()
                dict_measures[i][c]['variance_residual'] = variance_weighted(x=df['residuals'], weight=df['m_weight_employees'])
                wm = lambda x: np.average(x, weights=df.loc[x.index, "m_weight_employees"])
                func = {'m_weight_employees': 'sum', 'residuals': wm }
                df_firms = df.groupby(["m_firm_id"]).agg(func)
                dict_measures[i][c]['variance_between_residual'] = variance_weighted(x=df_firms['residuals'], weight=df_firms['m_weight_employees'])
                dict_measures[i][c]['variance_within_residual'] = dict_measures[i][c]['variance_residual'] - dict_measures[i][c]['variance_between_residual']     
                r_sq_firm_fixed = reg_class_ind_firm.r_squared() + (dict_measures[i][c]['variance_between_residual']/variance_weighted(x=df['ln_nwage'], weight=df['m_weight_employees']))
                df_rsquared.loc[i,c+'_fixed_firm'] = r_sq_firm_fixed
                df_rsquared.to_csv(ppj('OUT_DATA','rsquared_mincer.csv'))
                df_tertiary_param.to_csv(ppj('OUT_DATA','tertiary_params.csv'))
    with open(ppj('OUT_DATA','resid_variance_dict.json'), 'w') as fp:
        json.dump(dict_measures, fp)   
    return dict_measures

def variance_residuals_table(years, countries, measure, suffix):
    ''' Generate latex table with variance of residuals    
    of selected countries and years
    '''

    json_path = 'resid_variance_dict.json'
    with open(ppj('OUT_DATA',json_path)) as json_file:
        dict_measures_ = json.load(json_file)
    df_meas = pd.DataFrame(index=years, columns=countries)
    header = 'year'
    tab_cols = 'l'
    num_header=1
    for c in countries:
        header+= ' & ' + c
        tab_cols+='c'  
        num_header+=1      
    header += '\\\ \n'
    table_name = measure + '_summary' + suffix + '.tex'
    df_name = measure + '_summary' + suffix + '.csv'        
    with open(ppj('OUT_TABLES',table_name), 'w') as fw:
        fw.write('\\resizebox{0.9\\textwidth}{!}{')
        fw.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw.write(header)
        fw.write('\\hline \n')
        for y in years:
            row = str(y)
            for c in countries:
                print(c)
                print(y)
                print(measure)
                if y == 2002:
                    if c in ['Estonia', 'Hungary', 'Latvia', 'Sweden', 'Norway']:
                        str_c =  ' & '
                        row+= str_c
                        df_meas.loc[y,c] = ''
                    else:
                        str_c =  ' & ' + str("%.2f" % dict_measures_[str(y)][c][measure])
                        row+= str_c
                        df_meas.loc[y,c] = dict_measures_[str(y)][c][measure]                        
                else: 
                    str_c =  ' & ' + str("%.2f" % dict_measures_[str(y)][c][measure])
                    row+= str_c
                    df_meas.loc[y,c] = dict_measures_[str(y)][c][measure]
            row+='\\\ \n'
            fw.write(row)
        fw.write('\\multicolumn{'+str(num_header)+'}{p{1.1\\textwidth}}{\\footnotesize \\textit{Note: Table shows the decomposition of residual variance of normalised log gross hourly wages. The residuals are calculated from the estimated Mincerian wage equation that includes worker and firm characteristics.}}\\\ \n')    
        fw.write('\\multicolumn{'+str(num_header)+'}{p{1.1\\textwidth}}{\\footnotesize \\textit{Data: European Structure of Earnings Survey.}}\\\ \n')
        fw.write('\\end{tabular}} \n')     
    df_meas.to_csv(ppj('OUT_DATA',df_name),sep=';')  
    return df_meas    


years_all = [2002,2006,2010,2014]
measures_all = ['variance_residual', 'variance_between_residual', 'variance_within_residual']
cntries = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Netherlands', 'Norway', 'Poland', 'Romania', 'Slovakia']
cntries_cee = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Poland', 'Romania', 'Slovakia']
cntries_west = ['Netherlands', 'Norway', 'Portugal','Sweden']

variance_residuals_dict(countries=cntries_cee,years=[2002, 2006, 2010, 2014])
for m in measures_all:
    variance_residuals_table(years=years_all, countries=cntries_cee, measure=m, suffix="")
