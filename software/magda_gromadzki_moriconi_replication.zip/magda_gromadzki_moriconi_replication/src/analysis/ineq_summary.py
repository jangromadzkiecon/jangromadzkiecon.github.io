"""
Descriptive statistics for SES data
"""


import sys
import json
import logging
import pickle
import numpy as np
import pandas as pd
from src.data_management.read_data import import_dta 
from src.model_code.ineq_indices import mean_weighted, variance_weighted, atkinson, gini, theil_t, dispersion_quantiles, share_quantiles  
from bld.project_paths import project_paths_join as ppj

def ineq_meas_dict(years, countries, industry, sample):
    ''' Generate a dict with inequality indices
    for selected countries and years
    '''
    dict_measures = {}
    df_final = pd.DataFrame(index=years, columns=countries)
    for i in years:
        dict_measures[i]={}
        for c in countries:
            dict_measures[i][c]={}
            df_stata = import_dta(country=c, year=i)
            if sample=='baseline':
                df_stata = df_stata[df_stata['sample_999']==1]
                suff=""
                wage_var = 'ln_nwage'
            elif sample=='full':
                suff="_full"
                wage_var = 'ln_nwage_all'                
            if industry!='all':
                df_stata = df_stata[df_stata[industry]==1]
            df_stata = df_stata.dropna(subset=['m_earnings_euro'])
            df_stata = df_stata[df_stata['m_weight_employees']>0.]
            if len(df_stata)>0:
                dict_measures[i][c]['mean_earn_ann'] = mean_weighted(x=df_stata['m_earnings_ann'], weight=df_stata['m_weight_employees'])
                dict_measures[i][c]['mean_earn_ann_euro'] = mean_weighted(x=df_stata['m_earnings_ann_euro'], weight=df_stata['m_weight_employees'])                
                dict_measures[i][c]['variance'] = variance_weighted(x=df_stata['ln_nwage'], weight=df_stata['m_weight_employees'])
                dict_measures[i][c]['gini'] = gini(x=df_stata['m_earnings_euro'], weight=df_stata['m_weight_employees'])
                dict_measures[i][c]['atkinson_2'] = atkinson(x=df_stata['m_earnings_euro'], weight=df_stata['m_weight_employees'],epsilon=2.)
                dict_measures[i][c]['theil_t'] = theil_t(x=df_stata['m_earnings_euro'], weight=df_stata['m_weight_employees'])
                dict_measures[i][c]['90_10_dispersion'] = dispersion_quantiles(df_in=df_stata,earnings='m_earnings_euro', weight='m_weight_employees',nom=0.9,denom=0.1)
                dict_measures[i][c]['90_50_dispersion'] = dispersion_quantiles(df_in=df_stata,earnings='m_earnings_euro', weight='m_weight_employees',nom=0.9,denom=0.5)
                dict_measures[i][c]['50_10_dispersion'] = dispersion_quantiles(df_in=df_stata,earnings='m_earnings_euro', weight='m_weight_employees',nom=0.5,denom=0.1)
                dict_measures[i][c]['1_perc_share'] = share_quantiles(df_in=df_stata,earnings='m_earnings_euro', weight='m_weight_employees',quant=0.01)

                # now collapse to averages within firm and check variance between firms
                # define weighted mean function for groupby
                print(list(df_stata.columns))
                wm = lambda x: np.average(x, weights=df_stata.loc[x.index, "m_weight_employees"])
                # define a dict with the functions to apply to given columns
                func = {'m_weight_employees': 'sum', 'ln_nwage': wm }
                df_firms = df_stata.groupby(["m_firm_id"]).agg(func)
                print(df_firms)
                dict_measures[i][c]['variance_between'] = variance_weighted(x=df_firms['ln_nwage'], weight=df_firms['m_weight_employees'])
                dict_measures[i][c]['variance_within'] = dict_measures[i][c]['variance'] - dict_measures[i][c]['variance_between']
            else:
                for v in ['variance','gini','atkinson_2','variance_between',
                'variance_within','theil_t','90_10_dispersion','90_50_dispersion',
                '50_10_dispersion','1_perc_share','mean_earn_ann','mean_earn_ann_euro']:
                    dict_measures[i][c][v] = ''

    if industry=='all':
        json_path = 'ineq_dict' + suff + '.json'
    else:
        json_path = 'ineq_dict_' + industry + suff + '.json'
    with open(ppj('OUT_DATA',json_path), 'w') as fp:

        json.dump(dict_measures, fp)

    return dict_measures

def ineq_table(years, countries, measure, industry, suffix, json_path):
    ''' Generate latex table with inequality indices
    of selected countries and years
    '''
    with open(ppj('OUT_DATA',json_path)) as json_file:
        dict_measures_ = json.load(json_file)
    df_meas = pd.DataFrame(index=years, columns=countries)
    header = 'year'
    tab_cols = 'l'
    num_header=1
    for c in countries:
        header+= ' & ' + c
        tab_cols+='c'        
        num_header+=1
    header += '\\\ \n'
    if industry=='all':
        table_name = measure + '_summary' + suffix + '.tex'
        df_name = measure + '_summary' + suffix + '.csv'
    else: 
        table_name = measure + '_' + industry + '_summary' + suffix + '.tex'
        df_name = measure + '_' + industry + '_summary' + suffix + '.csv'        
    with open(ppj('OUT_TABLES',table_name), 'w') as fw:
        fw.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw.write(header)
        fw.write('\\hline \n')
        for y in years:
            row = str(y)
            for c in countries:
                print(c)
                print(y)
                print(measure)
                print(dict_measures_[str(y)][c][measure])
                if y == 2002:
                    if c in ['Estonia', 'Hungary', 'Latvia', 'Sweden', 'Norway', 'Portugal']:
                        str_c =  ' & '
                        row+= str_c
                        df_meas.loc[y,c] = ''
                    else:
                        str_c =  ' & ' + str("%.2f" % dict_measures_[str(y)][c][measure])
                        row+= str_c
                        df_meas.loc[y,c] = dict_measures_[str(y)][c][measure]                        
                else: 
                    str_c =  ' & ' + str("%.2f" % dict_measures_[str(y)][c][measure])
                    row+= str_c
                    df_meas.loc[y,c] = dict_measures_[str(y)][c][measure]
            row+='\\\ \n'
            fw.write(row)
        fw.write('\\multicolumn{'+str(num_header)+'}{l}{\\footnotesize \\textit{ Data: European Structure of Earnings Survey.}}\\\ \n')
        fw.write('\\end{tabular} \n')     
    df_meas.to_csv(ppj('OUT_DATA',df_name),sep=';')  
    return df_meas

measures_all = ['variance', 'gini', 'atkinson_2', 'variance_between', 
'variance_within','theil_t','90_10_dispersion', '50_10_dispersion', 
'90_50_dispersion' ,'1_perc_share']

cntries = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Netherlands', 'Norway', 'Poland', 'Portugal', 'Romania', 'Sweden', 'Slovakia']    
cntries_cee = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia', 
    'Poland', 'Romania', 'Slovakia']
cntries_west = ['Netherlands', 'Norway', 'Portugal', 'Sweden']
years_ = [2002,2006,2010,2014]


for i in ['all', 'nace_manu_constr', 'nace_mark_serv', 'nace_nonmark_serv']:
    ineq_meas_dict(years=years_, countries=cntries, industry=i,sample='baseline')
ineq_meas_dict(years=years_, countries=cntries, industry='all',sample='full')
for m in measures_all:
    ineq_table(years=years_, countries=cntries_cee, measure=m, industry='all', suffix="_full",json_path='ineq_dict_full.json')
    for i in ['all', 'nace_manu_constr', 'nace_mark_serv', 'nace_nonmark_serv']:
        if i=='all':
            json_path_ = 'ineq_dict.json'
        else:
            json_path_ = 'ineq_dict_' + i + '.json'        
        ineq_table(years=years_, countries=cntries_cee, measure=m, industry=i, suffix="",json_path=json_path_)
        ineq_table(years=years_, countries=cntries_west, measure=m, industry=i, suffix="_west",json_path=json_path_)


