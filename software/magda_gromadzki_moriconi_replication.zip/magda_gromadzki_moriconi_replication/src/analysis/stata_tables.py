"""
Generating latex tables based on Stata outreg2 outputs
"""

import sys
import json
import logging
import pickle
import numpy as np
import pandas as pd
from bld.project_paths import project_paths_join as ppj
import re

def rif_reg_df(countries,years,model_type, suff):
    ''' Return a dict of dataframes
    with regression results
    '''
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    dict_final = {}
    variables_all = []
    for c in countries:
        dict_final[c] = {}
        for y in years:
            if c in  ['Estonia', 'Hungary', 'Latvia', 'Sweden'] and y==2002:
                pass
            else:
                df_i = pd.DataFrame(columns=['coefficient', 'se'])
                num=0
                with open(ppj('OUT_DATA','rif_reg/' + str(country_codes[c]) + '_' + str(y) + '_results' + suff +'.txt'), 'r') as f:
                    for line in f:
                        num+=1
                        if num>3:
                            if line!='\t\n':
                                if num % 2 == 0:
                                    line = line.rstrip('\n')
                                    line_list = line.split('\t')
                                    # variable name, leave for next loop
                                    inx = line_list[0]
                                    inx = re.sub('_', '\\_', inx)
                                    if inx not in variables_all:
                                        variables_all.append(inx)
                                    df_i.loc[inx,'coefficient'] = line_list[1]
                                else:
                                    line = line.rstrip('\n')
                                    line_list = line.split('\t')                                
                                    df_i.loc[inx,'se'] = line_list[1]
                            else:
                                break
                res_list = []
                with open(ppj('OUT_DATA','rif_reg/' + str(country_codes[c]) + '_' + str(y) + '_results' + suff + '.txt'), 'r') as f:
                    for line in f:
                        line = line.rstrip('\n')
                        res_list.append(line)
                if model_type=="ols":
                    df_i.loc['R2','coefficient'] = res_list[-3].split('\t')[1]
                    df_i.loc['obs','coefficient'] = res_list[-4].split('\t')[1]
                elif model_type=="oaxaca":
                    df_i.loc['obs','coefficient'] = res_list[-3].split('\t')[1]
                dict_final[c][y]=df_i
    dict_final['variables'] = variables_all
    return dict_final

def oaxaca_detailed(countries, suff):
    ''' Return a dict of dataframes
    with regression results
    '''
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    dict_final = {}
    variables_all = []
    for c in countries:
        dict_final[c] = {}
        df_i = pd.DataFrame(columns=['Total Change', 'Composition', 'Wage Structure'])
        num=0
        with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[c]) + '_results' + suff + '.txt'), 'r') as f:
            for line in f:
                num+=1
                if num>3:
                    if '\t\t\t\t\n' not in line:
                        if num % 2 == 0:
                            line = line.rstrip('\n')
                            line_list = line.split('\t')
                            # variable name, leave for next loop
                            inx = line_list[0]
                            if inx not in ['group_1', 'group_2', 'difference']:
                                inx = re.sub('_', '\\_', inx)
                                #print(inx)
                                if inx not in variables_all:
                                    if inx not in  ["Total", 'Constant', 'explained', 'unexplained']:
                                        variables_all.append(inx)
                                df_i.loc[inx,'Total Change'] = line_list[1]        
                                df_i.loc[inx,'Composition'] = line_list[2]
                                df_i.loc[inx,'Wage Structure'] = line_list[3]
                    else:
                        break
            res_list = []
            df_i.loc['Total','Composition'] = df_i.loc['explained','Total Change']
            df_i.loc['Total','Wage Structure'] = df_i.loc['unexplained','Total Change']
            with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[c]) + '_results' + suff + '.txt'), 'r') as f:
                for line in f:
                    line = line.rstrip('\n')
                    res_list.append(line)
                df_i.loc['obs','Composition'] = res_list[-3].split('\t')[1]
            dict_final[c]=df_i
    variables_all = variables_all + ['Constant', 'Total']
    dict_final['variables'] = variables_all
    return dict_final

def oaxaca_detailed_quantiles(countries, suff):
    ''' Return a dict of dataframes
    with regression results
    '''
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Portugal': 'pt', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    dict_final = {}
    variables_all = []
    for c in countries:
        for dec in [10,50,90]: 
            dict_final[c] = {}
            df_i = pd.DataFrame(columns=['Total Change', 'Composition', 'Wage Structure'])
            num=0
            with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[c]) + '_results_q' + str(dec) + suff + '.txt'), 'r') as f:
                for line in f:
                    num+=1
                    if num>3:
                        if '\t\t\t\t\n' not in line:
                            if num % 2 == 0:
                                line = line.rstrip('\n')
                                line_list = line.split('\t')
                                # variable name, leave for next loop
                                inx = line_list[0]
                                if inx not in ['group_1', 'group_2', 'difference']:
                                    inx = re.sub('_', '\\_', inx)
                                    if inx not in variables_all:
                                        if inx not in  ["Total", 'Constant', 'explained', 'unexplained']:
                                            variables_all.append(inx)
                                    df_i.loc[inx,'Total Change'] = line_list[1]        
                                    df_i.loc[inx,'Composition'] = line_list[2]
                                    df_i.loc[inx,'Wage Structure'] = line_list[3]
                        else:
                            break
                res_list = []
                df_i.loc['Total','Composition'] = df_i.loc['explained','Total Change']
                df_i.loc['Total','Wage Structure'] = df_i.loc['unexplained','Total Change']
                with open(ppj('OUT_DATA','rif_reg/oaxaca0614_detail_' + str(country_codes[c]) + '_results' + suff + '.txt'), 'r') as f:
                    for line in f:
                        line = line.rstrip('\n')
                        res_list.append(line)
                    df_i.loc['obs','Composition'] = res_list[-3].split('\t')[1]
                dict_final[c+str(dec)]=df_i
    variables_all = variables_all + ['Constant', 'Total']
    dict_final['variables'] = variables_all
    return dict_final


def latex_rif_table(countries, years, variables_dict, suff):
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    nmprt = ''
    for i in countries:
        nmprt+=country_codes[i]
    out_path = 'rif_reg_' + nmprt + suff + '.tex' 
    rif_dict = rif_reg_df(countries=countries,years=years, model_type="ols", suff=suff)
    overheader = '\\multicolumn{1}{c}{ } '
    header = ''
    tab_cols = 'l'
    num_header=0
    for c in countries:
        if c in  ['Estonia', 'Hungary', 'Latvia', 'Sweden']:
            overheader += '& \\hphantom{ABC}  & \\multicolumn{' + str(len(years)-1) + '}{c}{'+ c + '} ' 
        else:
            overheader += '& \\hphantom{ABC} & \\multicolumn{' + str(len(years)) + '}{c}{'+ c + '} ' 
        tab_cols += 'c'
        header += ' & \\hphantom{ABC}'
        num_header+=1
        for y in years:
            if c in  ['Estonia', 'Hungary', 'Latvia', 'Sweden']:
                if y==2002:
                    pass
                else:
                    header+= ' & ' + str(y)
                    tab_cols += 'c'
                    num_header+=1                    
            else:
                header+= ' & ' + str(y)
                tab_cols += 'c'
                num_header+=1
    header += '\\\ \n'
    overheader += '\\\ \n'
    with open(ppj('OUT_TABLES',out_path), 'w') as fw:
        fw.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw.write(overheader)
        fw.write(header)
        fw.write('\\hline \n')
        fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{Individual effects}}\\\ \n')
        fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: primary education}}\\\ \n')
        for var in rif_dict['variables']:
            var_replaced = var.replace('\\', '')
            if var_replaced=='nace2_uni_dum1':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{}\\\ \n')
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{Firm effects}}\\\ \n')
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: NACE C}}\\\ \n')      
            elif var_replaced=='middle_age':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: under 30 years old}}\\\ \n') 
            elif var_replaced=='female':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: male}}\\\ \n')      
            elif var_replaced=='one_fouryearsexp':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: tenure of less than a year}}\\\ \n') 
            elif var_replaced=='occ_1d_dum1':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: ISCO 5}}\\\ \n') 
            elif var_replaced=='fixed_contract':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: permanent contract}}\\\ \n') 
            elif var_replaced=='m_pubcontr':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: private ownership of a firm}}\\\ \n') 
            line1 = variables_dict[var_replaced]
            for c in countries:
                line1+= ' & \\hphantom{ABC}'
                for y in years:
                    if y==2002 and c in  ['Estonia', 'Hungary', 'Latvia', 'Sweden']:
                        line1+= '' 
                    else:
                        df_sm = rif_dict[c][y]
                        if var in df_sm.index:
                            line1+= ' & ' + df_sm.loc[var,'coefficient']
                        else:
                            line1+= ' & ' 
            line1 += '\\\ \n'
            fw.write(line1)
        nobs_line = 'Observations'
        rsquared_line = 'R-squared'
        for c in countries:
            nobs_line+= ' & \\hphantom{ABC}'
            rsquared_line+= ' & \\hphantom{ABC}'
            for y in years:   
                if y==2002 and c in  ['Estonia', 'Hungary', 'Latvia', 'Sweden']:
                    nobs_line+='' 
                    rsquared_line+='' 
                else:
                    df_sm = rif_dict[c][y]
                    nobs_line+=' & ' + df_sm.loc['obs','coefficient']
                    rsquared_line += ' & ' + df_sm.loc['R2','coefficient']                    
        nobs_line += '\\\ \n'
        rsquared_line += '\\\ \n'
        fw.write(nobs_line)
        fw.write(rsquared_line)
        fw.write('\\hline \n')
        fw.write('\\end{tabular} \n')

def latex_oaxaca_detailed_table(countries, variables_dict, suff):
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    nmprt = ''
    for i in countries:
        nmprt+=country_codes[i]
    out_path = 'oaxaca_detailed_' + nmprt + suff + '.tex' 
    rif_dict = oaxaca_detailed(countries=countries, suff=suff)
    overheader = '\\multicolumn{1}{c}{ } '
    header = ''
    tab_cols = 'l'
    num_header=0
    for c in countries:
        tab_cols += 'c'
        header += ' & \\hphantom{ABC}'
        num_header+=1        
        overheader += '& \\hphantom{ABC} & \\multicolumn{2}{c}{'+ c + '} ' 
        for k in ['Composition', 'Wage Structure']:
            header+= ' & ' + k 
            tab_cols += 'c'
            num_header+=1
    header += '\\\ \n'
    overheader += '\\\ \n'
    with open(ppj('OUT_TABLES',out_path), 'w') as fw:
        fw.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw.write(overheader)
        fw.write(header)
        fw.write('\\hline \n')
        if suff!='_firms':
            fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{Individual effects}}\\\ \n')
            fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: primary education}}\\\ \n')
        for var in rif_dict['variables']:
            var_replaced = var.replace('\\', '')
            if var_replaced=='nace2_uni_dum1':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{}\\\ \n')
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{Firm effects}}\\\ \n')
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: NACE C}}\\\ \n')    
            elif var_replaced=='middle_age':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: under 30 years old}}\\\ \n') 
            elif var_replaced=='female':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: male}}\\\ \n')      
            elif var_replaced=='one_fouryearsexp':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: tenure of less than a year}}\\\ \n') 
            elif var_replaced=='occ_1d_dum1':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: ISCO 5}}\\\ \n') 
            elif var_replaced=='fixed_contract':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: permanent contract}}\\\ \n') 
            elif var_replaced=='m_pubcontr':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: private ownership of a firm}}\\\ \n')
            elif var_replaced=='Constant':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{}\\\ \n')
            if var_replaced in variables_dict.keys():
                line1 = variables_dict[var_replaced]
                for c in countries:
                    line1+=' & \\hphantom{ABC}'
                    for k in ['Composition', 'Wage Structure']:
                        df_sm = rif_dict[c]
                        if var in df_sm.index:
                            line1+= ' & ' + df_sm.loc[var,k]
                        else:
                            line1+= ' & '
                line1 += '\\\ \n'
                fw.write(line1)
        nobs_line = 'Observations'
        for c in countries:
            nobs_line+=' & \\hphantom{ABC}'
            df_sm = rif_dict[c]                    
            nobs_line+=' & ' + '\\multicolumn{2}{c}{' + df_sm.loc['obs','Composition'] +  '}' 
        nobs_line += '\\\ \n'
        fw.write(nobs_line)
        fw.write('\\hline \n')
        fw.write('\\end{tabular} \n')


def latex_oaxaca_quantile_detailed_table(country, variables_dict, suff):
    country_codes = {'Bulgaria': 'bg', 'Czechia': 'cz', 'Estonia': 'ee', 'Hungary': 'hu',
    'Lithuania': 'lt', 'Latvia': 'lv', 'Netherlands': 'nl', 'Poland': 'pl', 'Romania': 'ro',
    'Sweden': 'se', 'Slovakia': 'sk'}
    out_path = 'oaxaca_detailed_quantiles_' + country_codes[country] + suff + '.tex' 
    rif_dict = oaxaca_detailed_quantiles(countries=[country], suff=suff)
    overheader = '\\multicolumn{1}{c}{ } '
    header = ''
    tab_cols = 'l'
    num_header=0
    for dec in [10,50,90]:
        tab_cols += 'c'
        header += ' & \\hphantom{ABC}'
        num_header+=1        
        overheader += '& \\hphantom{ABC} & \\multicolumn{2}{c}{'+ str(dec) + 'th Quantile} ' 
        for k in ['Composition', 'Wage Structure']:
            header+= ' & ' + k 
            tab_cols += 'c'
            num_header+=1
    header += '\\\ \n'
    overheader += '\\\ \n'
    with open(ppj('OUT_TABLES',out_path), 'w') as fw:
        fw.write('\\begin{tabular}{' + tab_cols + '}\n')
        fw.write(overheader)
        fw.write(header)
        fw.write('\\hline \n')
        fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{Individual effects}}\\\ \n')
        fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: primary education}}\\\ \n')
        for var in rif_dict['variables']:
            var_replaced = var.replace('\\', '')
            if var_replaced=='nace2_uni_dum1':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{}\\\ \n')
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{Firm effects}}\\\ \n')
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: NACE C}}\\\ \n')    
            elif var_replaced=='middle_age':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: under 30 years old}}\\\ \n') 
            elif var_replaced=='female':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: male}}\\\ \n')      
            elif var_replaced=='one_fouryearsexp':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: tenure of less than a year}}\\\ \n') 
            elif var_replaced=='occ_1d_dum1':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: ISCO 5}}\\\ \n') 
            elif var_replaced=='fixed_contract':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: permanent contract}}\\\ \n') 
            elif var_replaced=='m_pubcontr':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{\\textit{reference: private ownership of a firm}}\\\ \n')
            elif var_replaced=='Constant':
                fw.write('\\multicolumn{'+str(num_header+1)+'}{l}{}\\\ \n')
            if var_replaced in variables_dict.keys():
                line1 = variables_dict[var_replaced]
                for dec in [10,50,90]:
                    line1+=' & \\hphantom{ABC}'
                    for k in ['Composition', 'Wage Structure']:
                        df_sm = rif_dict[country+str(dec)]
                        if var in df_sm.index:
                            line1+= ' & ' + df_sm.loc[var,k]
                        else:
                            line1+= ' & '
                line1 += '\\\ \n'
                fw.write(line1)
        nobs_line = 'Observations'
        for dec in [10,50,90]:
            nobs_line+=' & \\hphantom{ABC}'
            df_sm = rif_dict[country+str(dec)]                    
            nobs_line+=' & ' + '\\multicolumn{2}{c}{' + df_sm.loc['obs','Composition'] +  '}' 
        nobs_line += '\\\ \n'
        fw.write(nobs_line)
        fw.write('\\hline \n')
        fw.write('\\end{tabular} \n')



years_all = [2002,2006,2010,2014]
countries_list = ['Bulgaria', 'Czechia', 'Estonia', 'Hungary', 'Lithuania', 'Latvia',
'Poland', 'Romania', 'Slovakia']

vars_dict = {'tertiary_ed': 'tertiary education', 'secondary_ed': 'secondary education', 'middle_age': '30-49 years old',
'old_age': '50 years old or more', 'female': 'female', 'one_fouryearsexp': 'tenure: 1-4 years',
'five_nineyearsexp': 'tenure: 5-9 years', 'longexp': 'tenure: 10 years or more', 'occ1': 'ISCO 1-3', 
'occ2': 'ISCO 4-5', 'occ3': 'ISCO 6-8', 'nace_manu_constr': 'manufacturing and construction',
'nace_mark_serv': 'market services', 'm_pubcontr': 'public ownership of a firm', 'fixed_contract': 'fixed contract',
'tenure_below_two_firm_share': 'tenure: less than 2 years (share)', 'old_age_firm_share': 'age: 50 years or more (share)',
'tertiary_ed_firm_share': 'tertiary education (share)', 'female_firm_share': 'female (share)', 'Constant': 'constant', 'Total': 'total',
'nace2_uni_dum2': 'NACE C', 'nace2_uni_dum1': 'NACE B', 'nace2_uni_dum3': 'NACE D+E','nace2_uni_dum4': 'NACE F',
'nace2_uni_dum5': 'NACE G','nace2_uni_dum6': 'NACE H+J', 'nace2_uni_dum7': 'NACE I','nace2_uni_dum8': 'NACE K',
'nace2_uni_dum9': 'NACE L+M+N','nace2_uni_dum10': 'NACE O', 'nace2_uni_dum11': 'NACE P','nace2_uni_dum12': 'NACE Q', 
'nace2_uni_dum13': 'NACE R+S', 'occ_1d_dum1': 'ISCO 1', 'occ_1d_dum2': 'ISCO 2', 'occ_1d_dum3': 'ISCO 3', 'occ_1d_dum4': 'ISCO 4',
'occ_1d_dum5': 'ISCO 5', 'occ_1d_dum6': 'ISCO 6', 'occ_1d_dum7': 'ISCO 7', 'occ_1d_dum8': 'ISCO 8', 'occ_1d_dum9': 'ISCO 9'}

vars_dict_ordered = {'tertiary_ed': 'tertiary education', 'secondary_ed': 'secondary education', 'middle_age': '30-49 years old',
'old_age': '50 years old or more', 'female': 'female', 'one_fouryearsexp': 'tenure: 1-4 years',
'five_nineyearsexp': 'tenure: 5-9 years', 'longexp': 'tenure: 10 years or more', 
'nace2_uni_dum1': 'NACE B', 'nace2_uni_dum3': 'NACE D+E','nace2_uni_dum4': 'NACE F',
'nace2_uni_dum5': 'NACE G','nace2_uni_dum6': 'NACE H+J', 'nace2_uni_dum7': 'NACE I','nace2_uni_dum8': 'NACE K',
'nace2_uni_dum9': 'NACE L+M+N','nace2_uni_dum10': 'NACE O', 'nace2_uni_dum11': 'NACE P','nace2_uni_dum12': 'NACE Q', 
'nace2_uni_dum13': 'NACE R+S', 'occ_1d_dum1': 'ISCO 1', 'occ_1d_dum2': 'ISCO 2', 'occ_1d_dum3': 'ISCO 3', 'occ_1d_dum4': 'ISCO 4',
'occ_1d_dum6': 'ISCO 6', 'occ_1d_dum7': 'ISCO 7', 'occ_1d_dum8': 'ISCO 8', 'occ_1d_dum9': 'ISCO 9',
'm_pubcontr': 'public ownership of a firm',
'tenure_below_two_firm_share': 'tenure: less than 2 years (share)', 'old_age_firm_share': 'age: 50 years or more (share)',
'tertiary_ed_firm_share': 'tertiary education (share)', 'female_firm_share': 'female (share)',
 'Constant': 'constant'}

vars_dict_firms = { 'm_pubcontr': 'public ownership of a firm',
'tenure_below_two_firm_share': 'tenure: less than 2 years (share)', 'old_age_firm_share': 'age: 50 years or more (share)',
'tertiary_ed_firm_share': 'tertiary education (share)', 'female_firm_share': 'female (share)', 'Constant': 'constant', 'Total': 'total',
'nace2_uni_dum2': 'NACE C', 'nace2_uni_dum1': 'NACE B', 'nace2_uni_dum3': 'NACE D+E','nace2_uni_dum4': 'NACE F',
'nace2_uni_dum5': 'NACE G','nace2_uni_dum6': 'NACE H+J', 'nace2_uni_dum7': 'NACE I','nace2_uni_dum8': 'NACE K',
'nace2_uni_dum9': 'NACE L+M+N','nace2_uni_dum10': 'NACE O', 'nace2_uni_dum11': 'NACE P','nace2_uni_dum12': 'NACE Q', 
'nace2_uni_dum13': 'NACE R+S'}


for c in countries_list:
    latex_oaxaca_quantile_detailed_table(country=c, variables_dict=vars_dict, suff="")

dict_su={'':vars_dict, '_nopublic':vars_dict, '_firms':vars_dict_firms}

for su in ['', '_nopublic','_firms']:
    latex_rif_table(countries=['Bulgaria', 'Romania'], years=years_all, variables_dict=dict_su[su], suff = su)
    latex_rif_table(countries=['Czechia', 'Slovakia'], years=years_all, variables_dict=dict_su[su], suff = su)
    latex_rif_table(countries=['Estonia', 'Poland'], years=years_all, variables_dict=dict_su[su], suff = su)
    latex_rif_table(countries=['Lithuania', 'Latvia'], years=years_all, variables_dict=dict_su[su], suff = su)
    latex_rif_table(countries=['Hungary'], years=years_all, variables_dict=dict_su[su], suff = su)

    latex_oaxaca_detailed_table(countries=['Bulgaria','Czechia','Estonia'], variables_dict=dict_su[su], suff = su)
    latex_oaxaca_detailed_table(countries=['Latvia', 'Lithuania','Hungary'], variables_dict=dict_su[su], suff = su)
    latex_oaxaca_detailed_table(countries=['Poland', 'Romania', 'Slovakia'], variables_dict=dict_su[su], suff = su)

