import sys
import json
import logging
import pickle
from bld.project_paths import project_paths_join as ppj



def variance_within_table(countries, level_year, ref_year, suffix):
    ''' Generate a table with changes of the share of within variance component
    '''
    with open(ppj('OUT_DATA', 'ineq_dict.json')) as json_file:
        dict_measures_ = json.load(json_file)
    header = ' & Level ' + str(level_year) + ' & Change ' + \
        str(level_year) + '-' + str(ref_year) + '\\\ \n'
    header_down = ' & (percent) & (percent) \\\ \n'
    with open(ppj('OUT_TABLES', 'variance_within_changes' + suffix + '.tex'), 'w') as fw:
        fw.write('\\begin{tabular}{lcc}\n')
        fw.write(header)
        fw.write(header_down)
        fw.write('\\hline \n')
        for c in countries:
            level_var = 100 * dict_measures_[str(level_year)][c]['variance_within'] / dict_measures_[str(level_year)][c]['variance']
            if level_year == 2002:
                if c in ['Estonia', 'Hungary', 'Latvia', 'Sweden', 'Portugal', 'Norway']:
                    change_within = abs(dict_measures_[str(level_year)][c]['variance_within'] - dict_measures_[str(2006)][c]['variance_within'])
                    change_total = abs(dict_measures_[str(level_year)][c]['variance_within'] - dict_measures_[str(2006)][c]['variance_within']) + abs(dict_measures_[str(level_year)][c]['variance_between'] - dict_measures_[str(2006)][c]['variance_between'])
                    change_perc = 100*change_within/change_total
                else:
                    change_within = abs(dict_measures_[str(level_year)][c]['variance_within'] - dict_measures_[str(ref_year)][c]['variance_within'])
                    change_total = abs(dict_measures_[str(level_year)][c]['variance_within'] - dict_measures_[str(ref_year)][c]['variance_within']) + abs(dict_measures_[str(level_year)][c]['variance_between'] - dict_measures_[str(ref_year)][c]['variance_between'])
                    change_perc = 100*change_within/change_total
            else:
                    change_within = abs(dict_measures_[str(level_year)][c]['variance_within'] - dict_measures_[str(ref_year)][c]['variance_within'])
                    change_total = abs(dict_measures_[str(level_year)][c]['variance_within'] - dict_measures_[str(ref_year)][c]['variance_within']) + abs(dict_measures_[str(level_year)][c]['variance_between'] - dict_measures_[str(ref_year)][c]['variance_between'])
                    change_perc = 100*change_within/change_total
            linew = c + ' \\hphantom{ABCDEFG} & ' + str("%.0f" % level_var) + ' & ' + str("%.0f" % change_perc) + '\\\ \n'
            fw.write(linew)
        #fw.write('\\multicolumn{3}{l}{\\begin{tabular}[c]{@{}l@{}}\\footnotesize Note: the first column shows the contribution\\\ \\footnotesize of the within-firm component to the level of the variance of log\\\ \\footnotesize wages in 2006 ($\\frac{Var(within_{2006})}{Var(\hat{w_{i,2006}})}$). The unreported between component is 100\\% minus the reported\\\ \\footnotesize  within component. The second column shows the contribution of the within\\\ \\footnotesize component to the change of the variance \\\ \\footnotesize ($\\frac{\\mid\\Delta Var(within)\\mid}{(\\mid\\Delta Var(within)\\mid + \\mid\\Delta Var(betweem)\\mid)}$)\\end{tabular}}\\\ \n')
        fw.write('\\multicolumn{3}{p{0.75\\textwidth}}{\\footnotesize \\textit{Note: the first column shows the contribution of the within-firm component to the level of the variance of log wages in 2006 ($\\frac{Var(within_{2006})}{Var(\hat{w_{i,2006}})}$). The unreported between component is 100\\% minus the reported within component. The second column shows the contribution of the within component to the change of the variance ($\\frac{\\mid\\Delta Var(within)\\mid}{(\\mid\\Delta Var(within)\\mid + \\mid\\Delta Var(between)\\mid)}$).}}\\\ \n')
        fw.write('\\multicolumn{3}{l}{\\footnotesize \\textit{Data: European Structure of Earnings Survey.}}\\\ \n')
        fw.write('\\end{tabular} \n') 


cntries_cee = ['Estonia', 'Czechia', 'Slovakia', 'Lithuania', 'Hungary',  'Latvia',    
    'Poland', 'Romania','Bulgaria']
cntries_west = ['Netherlands', 'Norway', 'Sweden', 'Portugal']
variance_within_table(countries=cntries_cee, level_year=2006, ref_year=2014, suffix="")
variance_within_table(countries=cntries_west, level_year=2006, ref_year=2014, suffix="_west")

