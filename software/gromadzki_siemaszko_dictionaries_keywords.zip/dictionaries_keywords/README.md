# Emotion dictionaries

We compiled dictionaries with emotion-related words in English (dict_emotions_en.json), and in Polish (dict_emotions_pl.json). The English dictionary is based on the NRCLex library. The English dictionary was translated to Polish using the googletrans library. Each dictionary is a dictionary of dictionaries. At the top level, there are nine keys related to sentiment or emotion: 'fear', 'anger', 'negative', 'anticipation', 'trust', 'surprise', 'positive', 'sadness', 'disgust', 'joy'. The values for these nested dictionaries are lists of tokens corresponding to lemmas associated with a given emotion or sentiment. Lemmatization was conducted using the Spacy library.

Example use in Python: 

	with open('dict_emotions_pl.json', encoding='utf-8') as json_file:
		dict_pl = json.load(json_file) 
		list_fear_pl = dict_pl['fear']

# Topic dictionaries

We compiled dictionaries with topic-related keywords in English (dict_keywords_en.json), and in Polish (dict_keywords_pl.json). At the top level, there are nine keys related to topics: 'politics', 'swear', 'school', 'religion', 'family', 'friend', 'boygirl', 'love', 'pedophile', 'sex', 'culture', 'pet', 'police', 'lgbtq', 'alcohol', 'period', 'illness', 'protest', 'jewish', 'bialystok'. The values for these nested dictionaries are lists of tokens corresponding to keyword lemmas associated with a given topic. Lemmatization was conducted using the Spacy library.

Example use in Python: 

	with open('dict_keywords_pl.json', encoding='utf-8') as json_file:
		dict_topics_pl = json.load(json_file) 
		list_swears_pl = dict_topics_pl['swear']

As per the terms of use of the dictionaries, if you use them, cite this paper: Gromadzki, J., & Siemaszko, P. (2022). #IamLGBT: Social Networks and Coming Out. IBS Working Paper 06/2022. The full documentation is available in the Appendix G in this paper.

# References

Bird, Steven, Edward Loper and Ewan Klein (2009), Natural Language Processing with Python. O’Reilly Media Inc.
Gromadzki, J., & Siemaszko, P. (2022). #IamLGBT: Social Networks and Coming Out. IBS Working Paper 06/2022. 
Mohammad, S. M., & Turney, P. D. (2013). Crowdsourcing a word–emotion association lexicon. Computational intelligence, 29(3), 436-465.
https://pypi.org/project/googletrans/
https://spacy.io/
